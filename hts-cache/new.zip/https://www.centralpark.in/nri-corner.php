
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#ffffff">
        <title>Explore NRI Corner at Central Park for Luxurious Living in Gurgaon</title>
    <meta name="description" content="Explore real estate investment opportunities in Gurgaon with Central Park for NRI investors. Offering luxury properties that ensure customer satisfaction, growth, and long-term returns.">
    <meta name="keywords" content="Luxury residences in gurgaon, Luxury apartments in gurgaon for rent, Best luxury residential homes in Gurgaon, Luxury residential projects in gurgaon.">
    <meta name="robots" content="noodp">
    <meta property="og:title" content="Explore NRI Corner at Central Park for Luxurious Living in Gurgaon">
    <meta property="og:site_name" content="Central Park - Luxury Housing">
    <meta property="og:url" content="https://www.centralpark.in/nri-corner.php">
    <meta property="og:description" content="Explore real estate investment opportunities in Gurgaon with Central Park for NRI investors. Offering luxury properties that ensure customer satisfaction, growth, and long-term returns.">
    <meta property="og:image" content="https://www.centralpark.in/images/logo.png">
    <meta name="twitter:title" content="Explore NRI Corner at Central Park for Luxurious Living in Gurgaon">
    <meta name="twitter:description" content="Explore real estate investment opportunities in Gurgaon with Central Park for NRI investors. Offering luxury properties that ensure customer satisfaction, growth, and long-term returns.">
    <meta name="twitter:image" content="https://www.centralpark.in/images/logo.png">
    
        <link rel="canonical" href="https://www.centralpark.in/nri-corner.php">
        
    
    <!--Schema Tags-->
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Central Park",
  "url": "https://www.centralpark.in/",
  "logo": "https://www.centralpark.in/images/logo2.svg",
  "sameAs": [  
    "https://www.facebook.com/CentralParkIn/",    
    "https://twitter.com/CentralParkIn",
    "https://www.instagram.com/centralparkin/",
    "https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ",
    "https://www.linkedin.com/company/central-park-in/",
    "https://www.centralpark.in/"
  ]
}
</script>    <!--Stylecss-->
    
    <link rel="icon" type="image/x-icon" href="https://www.centralpark.in/images/faviv2.ico">
    <link rel="stylesheet" href="https://www.centralpark.in/css/style.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/responisve.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/animate.css"> 
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick-theme.css">  
    <link rel="stylesheet" href="https://www.centralpark.in/css/eocjs-newsticker.css">
   <link rel="stylesheet" href="https://www.centralpark.in/css/font-awesome.min.css">
   <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.0/css/all.min.css" integrity="sha512-9xKTRVabjVeZmc+GUW8GgSmcREDunMM+Dt/GrzchfN8tkwHizc5RP4Ok/MXFFy5rIjJjzhndFScTceq5e6GvVQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />-->
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/OPTIMA.woff" type="font/woff" crossorigin="anonymous">
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/fontawesome-webfont.woff2?v=4.7.0" type="font/woff2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />--><!-- Facebook Pixel Code -->

<script>


!function(f,b,e,v,n,t,s)



{if(f.fbq)return;n=f.fbq=function(){n.callMethod?



n.callMethod.apply(n,arguments):n.queue.push(arguments)};



if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';



n.queue=[];t=b.createElement(e);t.async=!0;



t.src=v;s=b.getElementsByTagName(e)[0];



s.parentNode.insertBefore(t,s)}(window,document,'script',



'https://connect.facebook.net/en_US/fbevents.js');



fbq('init', '394540540386962');



fbq('track', 'PageView');


</script>

<noscript>

<img height="1" width="1"

src="https://www.facebook.com/tr?id=394540540386962&ev=PageView

&noscript=1"/>

</noscript>

<!-- End Facebook Pixel Code -->

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K5WV3Q');</script>
<!-- End Google Tag Manager -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-60041058-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-60041058-1');
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16495080556"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-16495080556');
</script>

<script>
  gtag('config', 'AW-16495080556/znPoCOHsm6UZEOzou7k9', {
    'phone_conversion_number': '+91 7065777702'
  });
</script>

<!-- Taboola Pixel Code -->
<!--<script type='text/javascript'>
  window._tfa = window._tfa || [];
  window._tfa.push({notify: 'event', name: 'page_view', id: 1429034});
  !function (t, f, a, x) {
         if (!document.getElementById(x)) {
            t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f);
         }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/unip/1429034/tfa.js',
  'tb_tfa_script');
</script>-->
<!-- End of Taboola Pixel Code -->


</head>

<body>
    
    <style>
        
        header {
    background: #00000014;
}
    </style>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K5WV3Q"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!-- Event snippet for Website Traffic views conversion page -->


    <div class="jsOverlay"></div>
    <div class="mainwrap">
            <style>
            span.s__0999 {
    background: transparent!important;
    font-size: 42px;
    color: #9e8061;
}
      
      .mainwrap .hospitalitysection .hospiinner {
    width: 100%;
    float: left;
    padding: 63px 0;
}      
     body.black_bg .logo-white {
    display: block;
}
            .mainwrap header .navigation .left .logo img {
   
    top: 0px!important;
}  
            
            .banner-caption {
    margin: auto;
    padding: 146px 0 13px;
    text-align: center;
}
            
            .valley_prallax .h3 {
    margin-bottom: 34px;
}  
            .valley_prallax {
    padding-top: 148px;
}
</style>
        <header>  
            <div class="navigation">
                <div class="width90">
                    <div class="left">
                        <div class="logo d-flex">
                            <a href="https://www.centralpark.in/" class="">
                                <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="49" class="logo-white lazy" alt="Central Park Logo">-->
                                <!--<img src="https://www.centralpark.in/images/logo2.svg" width="227" height="49" class="logo-black lazy" alt="Central Park Logo">-->
                                <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="49" class="logo-white lazy" alt="Central Park Logo">
                            </a>
                                                        <img src="https://www.centralpark.in/images/20-Years.svg" width="34" height="62" class="years20 lazy" alt="Central Park - 20 Years of curating a privileged lifestyle">
                                                    </div>
                    </div>
                    <div class="right">
                        <div class="headernav">
                            <div class="navtoggle opennav">
                                <a href="javascript:void(0)" title="Open">
                                    <span></span>
                                    <span></span>
                                </a>
                            </div>
                            <div class="topsmnav">
                                <ul>
                                    <!--<li><a href="https://www.centralpark.in/pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                    <li><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></li>
                                    <!--<li><a href="javascript:void(0)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">-->
                                    <!--    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>-->
                                    <!--  </svg></a></li>-->
                                </ul>
                            </div>
                            <div class="mainnav">
                                <ul>
                                    <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                    <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                    <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                    <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                </ul>
                            </div>                            
                        </div>
                    </div>
                </div>
                <div class="windowheightnav">
                    <div class="navclose closenav">
                        <a href="javascript:void(0)" title="Close">
                            <span class="s__0999">x</span>  
                        </a>
                    </div>
                    <div class="windogrid">
                        <div class="lrsection">
                            <div class="parknavbar">
                                 <div class="width70">
                                     
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/residential.php">Residential</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/commercial.php">Commercial</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></strong>
                                    </div>
                                    
                                     <div class="innernavbar">
                                         <span>&nbsp;</span>
                                         <strong><a href="https://www.centralpark.in/about-us.php">About Us</a></strong>
                                         <ul>
                                             <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#team">LEADERSHIP</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                         </ul>
                                     </div>

                                     <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/group.php">Group</a></strong>
                                        <ul>
                                            <li><a href="https://www.centralpark.in/group.php#automotive">Automotive</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#infrastructure">Infrastructure</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#education">Education</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#hospitality">Hospitality</a></li>
                                        </ul> 
                                    </div>

                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/media.php">Media</a></strong>
                                         <ul>
                                            <li><a href="https://www.centralpark.in/media.php#tab1" onClick="loadmr('1');">News Coverage </a></li>
                                            <li><a href="https://www.centralpark.in/media.php#tab2" onClick="loadmr('2');">VIDEO GALLERY</a></li>
                                        </ul> 
                                    </div>
                                    
                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></strong>
                                    </div>
                                    
                                    <div class="d-none top-menu-headr">
                                        <ul class="small-menu_list">
                                            <!--<li><a href="pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                        </ul>
                                    </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        
        
      <div class="popup custom-popup" data-popup="popup-1">
    <div class="popup-inner">
        <h2>Enquire Now</h2>
        
        <div class="pd100  contact-wrapper">
       
                <div class="form">
                    <p id="success_1" style="color: green;font-size: 14px;"></p>
                    <p id="reCaptchaError_1" style="color:red;"></p>
                    <form action="enquireData.php" method="POST" id="enquire_now_form">
                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control let" placeholder="Name" name="enquire_now_name" id="enquire_now_name">
                        </div>
                        <div class="form-group w50 lt-50">
                           <input type="text" class="form-control" placeholder="Email"  name="enquire_now_email" id="enquire_now_email">
                        </div>

                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control" placeholder="Phone Number" name="enquire_now_phone" id="enquire_now_phone" maxlength="10" onkeypress="return isNumberKey(event,this)">
                        </div>
                        
                        <div class="form-group w50 lt-50">
                            <select class="form-control" name="enquire_now_project" id="enquire_now_project">
                              <option value="">Select Projects</option>
                              <option value="Aqua Front Tower&Central Park Flower Valley">Aqua Front Tower</option>
                              <option value="Central Park Flower Valley&Central Park Flower Valley">Central Park Flower Valley</option>
                              <option value="Cerise Floors&Central Park Flower Valley">Cerise Floors</option>
                              <option value="Clover Floors&Central Park Flower Valley">Clover Floors</option>
                              <option value="Flamingo Floors&Central Park Flower Valley">Flamingo Floors</option>
                              <option value="Fleur Villa&Central Park Flower Valley">Fleur Villa</option>
                              <option value="Mikasa&Central Park Flower Valley">Mikasa</option>
                              <option value="The Room - Flower Valley&Central Park Flower Valley">The Room - Flower Valley</option>
                              <option value="Beau Villas&Central Park Resorts">Beau Villas</option>
                              <option value="Belgravia Apartments&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Bellavista&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Central Park Resorts&Central Park Resorts">Central Park Resorts</option>
                              <option value="The Room&Central Park Resorts">The Room</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                           <textarea  class="form-control" placeholder="Message" name="enquire_now_msg" id="enquire_now_msg" rows="1"></textarea>
                        </div>
                        <input type="hidden" name="page_source" value="">

                      
                        
                        <button class="btn btn_submit btnSubmit"  type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72">
                                <defs>
                                    <style>
                                        .cls-1 {
                                            fill: none;
                                            stroke: #9e8061;
                                            stroke-miterlimit: 10;
                                        }
                                    </style>
                                </defs>
                                <g id="Layer_10" data-name="Layer 2">
                                    <g id="Layer_1-10" data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"></path></g>
                                </g>
                            </svg>
                            <span>Submit<b class="upcom"></b></span> 
                        </button>
                    </form>
                </div>
            </div>
            
        

        
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
    </div>
</div>  
<div class="scroller smooth_scroll" id="overflowScroll">
       <div class="banner">
           <div class="width90">
               
            <div class="banner-caption">
                <div class="text-center">
                    <span>NRI CORNER</span> 
                </div>
                <h1>Be a part of an enriching odyssey.</h1>
            </div>
            <div class="breadcrumbslist wow animate__animated cog_js animated">
                <ul>
                    <li><a href="https://www.centralpark.in/">Home</a></li>
                    <li>NRI Corner</li>
                </ul>
            </div>
            <div class="prallax-cp">
                <img src="images/mri-Banner.jpg" class="w-100 wow animate__animated animate__fadeIn" alt="NRI Corner - Central Park - 1" />
            </div>
            <div class="para_content mb-00">
                
                <p class="wow animate__animated animate__fadeInUp mb-0-mobile" style="padding-bottom: 80px !important;">
                    With 20 years of curating privileged lifestyle, Central Park has an unrivalled expertise in translating elegant designs to desirable living spaces of highest standards of global quality. Providing units with well-rounded infrastructure including penthouses, villas, floors, studios and group housing, Central Park is the creator of iconic spaces. It is one of the fastest growing ultra-luxury realty brands, which has luxury hospitality imbibed in its brand philosophy.
                </p>
            </div>
            </div><!--width90-->
        </div>
</div><!--scroll--> 

       <!--<div class="banner pdb100">
           <div class="width90">
               
            <div class="banner-caption">
                <div class="text-center">
                    <span>NRI CORNER</span> 
                </div>
                <h1>Be a part of an enriching odyssey</h1>
                <p class="wow animate__animated cog_js" >Units with well-rounded infrastructure, penthouses, villas and bungalows in gated communities, besides branded residences and golf townships are popular. Homes with incredible views, set in a big piece of land and a notable architecture, that supports their vision of modern, luxurious, and sustainable living. Extra room that could be converted into a study room, or perhaps a little more seating space within the bedroom where they can set up their own temporary workstations.</p>
            </div>
            <div class="prallax-cp">
                <img src="images/mri-Banner.jpg" class="w-100 wow animate__animated animate__fadeIn" />
            </div>

            </div>
        </div>-->
        
        <div id="whyindia">
            <div class="whywraptext pad100 pdb0">
                <div class="width90">
                    <div class="tabbed-content">
                            <nav class="tabs text-center">
                                <ul>
                                    <li><a href="#tab1" class="active">Why India</a></li>
                                    <li><a href="#tab2">Why Gurugram?</a></li>
                                </ul>
                            </nav>
                            <div id="tab1" class="item active" data-title="Why India">
                                <div class="item-content">
                                    <div class="itemsgrid">
                            <div class="leftgrid">
                                <ul>
                                    <li class="wow animate__animated cog_js"><b>Positive Demographics</b> India has a youthful, educated, and growing workforce. The increase in population opens new emerging markets, customers and products.</li>
                                    <li class="wow animate__animated cog_js"><b>Strong Economic Growth</b> India has realized strong historical growth rates, particularly in the information technology and business process outsourcing sectors. These continue to be among the largest sectors of the global economy.</li>
                                    <li class="wow animate__animated cog_js"><b>Stable Government</b> India has maintained a strong parliamentary democracy ever since its independence in 1947.</li>
                                    <li class="wow animate__animated cog_js"><b>No restriction on the number of permitted immovable properties </b> There is no restriction on the number of immovable properties both NRIs or OCIs may hold. They are also allowed to inherit any immovable property in India.</li>
                                </ul>
                            </div>
                        </div>
                                </div>
                            </div>
                            
                            <div id="tab2" class="item" data-title="Why Gurugram?">
                                <div class="item-content">
                                    <div class="itemsgrid">
                            <div class="rightgrid">
                                    <ul>
                                      <li class="wow animate__animated cog_js"><b>Better connectivity</b> Infrastructural advancements in Gurugram's outskirts have reduced travel time to the city centres. It is just a swift 35-kilometre drive away from Delhi.</li>
                                      <li class="wow animate__animated cog_js"><b>Education and Health hub</b> With the presence of prominent schools, colleges and premium hospitals and even prominent hotels, Gurugram has emerged as a self-sustaining region with upgraded infrastructure and amenities of all kinds.</li>
                                      <li class="wow animate__animated cog_js"><b>Expatriates’ Hub</b> With a plethora of upscale housing options, renowned hospitality chains and lush greenery owing to biodiversity, Gurugram, also known as the Millennium City, is a preferred location for the expats.</li>
                                      <li class="wow animate__animated cog_js"><b>Centre for Commercial offices & industries</b> Nearly 250 Fortune 500 companies have set up their base in Gurgaon. Global giants such as Coca-Cola, BMW, Pepsi etc. have their offices here. With Gurugram emerging as the most sought after destination for expats, it has developed into a hub for automotive industries.</li>
                                      <li class="wow animate__animated cog_js"><b>Improved Lifestyle</b> Gurugram provides luxury in each detail. Shopping malls, five-star hotels, restaurants, pubs, entertainment zones and golf course add the international vibe to the city. </li>
                                      <li class="wow animate__animated cog_js"><b>Vicinity to International Airport</b> Gurugram’s proximity to the International Airport terminal makes it well connected by all modes of transport.</li>
                                    </ul>
                            </div>
                        </div>
                                </div>
                            </div>


                    </div>
                    <!--<div class="flexfull">
                        <div class="itemsgrid">
                            <div class="leftgrid">
                                  <h4 class="h2 wow animate__animated cog_js" >Why India</h4>
                                <ul>
                                    <li class="wow animate__animated cog_js"><b>Positive Demographics</b>India has a youthful, educated, and growing workforce. The increase in population opens new emerging markets, customers and products.</li>
                                    <li class="wow animate__animated cog_js"><b>Strong Economic Growth</b> India has realized strong historical growth rates, particularly in the information technology and business process outsourcing sectors. These continue to be among the largest sectors of the global economy.</li>
                                    <li class="wow animate__animated cog_js"><b>Stable Government</b>India has maintained a strong parliamentary democracy ever since its independence in 1947.</li>
                                    <li class="wow animate__animated cog_js"><b>No restriction on the number of permitted immovable properties </b> There is no restriction on the number of immovable properties both NRIs or OCIs may hold. They are also allowed to inherit any immovable property in India.</li>
                                </ul>
                            </div>
                        </div>
                        <div class="itemsgrid">
                            <div class="rightgrid">
                              <h4 class="h2 wow animate__animated cog_js">Why Gurugram?</h4>
                                    <ul>
                                      <li class="wow animate__animated cog_js"><b>Better connectivity</b> Infrastructural advancements in Gurugram's outskirts have reduced travel time to the city centres. It is just a swift 35-kilometre drive away from Delhi.</li>
                                      <li class="wow animate__animated cog_js"><b>Education and Health hub</b> With the presence of prominent schools, colleges and premium hospitals and even prominent hotels, Gurugram has emerged as a self-sustaining region with upgraded infrastructure and amenities of all kinds.</li>
                                      <li class="wow animate__animated cog_js"><b>Expatriates’ Hub</b> With a plethora of upscale housing options, renowned hospitality chains and lush greenery owing to biodiversity, Gurugram, also known as the Millennium City, is a preferred location for the expats.</li>
                                      <li class="wow animate__animated cog_js"><b>Centre for Commercial offices & industries</b> Nearly 250 Fortune 500 companies have set up their base in Gurgaon. Global giants such as Coca-Cola, BMW, Pepsi etc. have their offices here. With Gurugram emerging as the most sought after destination for expats, it has developed into a hub for automotive industries.</li>
                                      <li class="wow animate__animated cog_js"><b>Improved Lifestyle</b> Gurugram provides luxury in each detail. Shopping malls, five-star hotels, restaurants, pubs, entertainment zones and golf course add the international vibe to the city. </li>
                                      <li class="wow animate__animated cog_js"><b>Vicinity to International Airport</b> Gurugram’s proximity to the International Airport terminal makes it well connected by all modes of transport.</li>
                                    </ul>
                            </div>
                        </div>
                    </div>-->
                </div>
            </div>
        </div>
  
  
  <div class="nri-box pad100"  style="display:none;">
      <div class="width90">
          <div class="flex">
              <div class="nri-img wid60">
                  <h4 class="h2 wow animate__animated cog_js" >Why India</h4>
                  <ul>
                      <li class="wow animate__animated cog_js"><b>Positive Demographics</b> India has a youthful, educated, and growing workforce that should help support its economic growth, assuming that the country's educational system effectively teaches them how to contribute to the economy over time.</li>
                      <li class="wow animate__animated cog_js"><b>Strong Economic Growth</b> India has realized strong historical growth rates, particularly in the information technology and business process outsourcing sectors. These continue to be among the largest sectors of the global economy as a whole.</li>
                      <li class="wow animate__animated cog_js"><b>Stable Government</b> India has maintained a strong parliamentary democracy since its political freedom from Britain some 50 years ago. In 2014, Narendra Modi was elected prime minister and has made great strides in improving the economy.</li>
                      <li class="wow animate__animated cog_js"><b>No restriction on the number of permitted immovable properties</b> that both NRIs and OCIs may hold, and rental income (for NRIs) can be repatriated freely from India without taking any specific permission. No income tax implications at the time of acquisition is another favourable policy.</li>
                  </ul>
              </div>
              <div class="nri-img wid40 pad-lt60">
                   <img src="images/How.jpg" class="w-100 wow animate__animated animate__fadeIn"   alt="NRI Corner - Central Park - 2"/>
              </div>
          </div>
      </div>
  </div>
  
  
    <div class="nri-box pad100 grey" style="display:none;">
      <div class="width90">
          <div class="flex">
              <div class="nri-img wid40">
                   <img src="images/Why.jpg" class="w-100 wow animate__animated animate__fadeIn" alt="NRI Corner - Central Park - 3"/>
              </div>
                <div class="nri-img pad-lt60 wid60">
                  <h4 class="h2 wow animate__animated cog_js">Why Gurugram?</h4>
                        <ul>
                          <li class="wow animate__animated cog_js">Demand fundamentals remain strong on account of healthy office space absorption and the city’s position as the preferred residential destination for upper levels of management across various corporations.</li>
                          <li class="wow animate__animated cog_js">Quality of construction, amenities, specifications and proximity to social infrastructure will continue to act as drivers for improved demand momentum.</li>
                          <li class="wow animate__animated cog_js">Luxury housing is based on concepts of niche address and limited upcoming supply, especially on the Golf Course Road</li>
                          <li class="wow animate__animated cog_js">Interest rate softening may have a positive impact as end-user buyers, especially salaried professionals (the upper-tier management) are looking to upgrade to luxury accommodation by selling off older investments and bridging the gap through bank loans</li>
                          <li class="wow animate__animated cog_js">Secondary market transactions for completed and close to completion projects is likely to inject momentum in the primary market going forward. </li>
                          <li class="wow animate__animated cog_js">Primary investments have come in from those settled in the UAE, Singapore, the UK and US, for properties across segments: residential, commercial and even warehousing.</li>
                        </ul>
                </div>
              
          </div>
      </div>
  </div>
  
  
  <div class="nri-box pad100" id="faq">
      <div class="width90">
          <h4 class="h2 wow animate__animated cog_js">FAQ’s</h4>
          <!--<p>Can include offers that target NRIs and make investing lucrative for them. <br> Not a lot of NRI related content available on CP website.</p>-->
          
          
          
          <div class="step_wrapper mb-5">
                     
            <div class="step_box wow animate__animated cog_js" id="one">
                    <a href="javascript:void(0)">
                        <span>Who is a Non-Resident Indian (NRI)?
<img src="images/arrow-tab.svg" alt="Arrow - Central Park" /></span>
                    </a>
                    <div class="step_content" id="one_open">
                       <p>An Indian citizen who lives abroad for employment/carrying on business or vocation outside India or stays abroad under circumstances indicating an intention for an uncertain duration of stay abroad is a non-resident. Non-resident foreign citizens of Indian origin are treated on par with non- resident Indian citizens (NRIs).
</p>
                    </div>
            </div>
                   
            <div class="step_box wow animate__animated cog_js"  id="two">
                    <a href="javascript:void(0)">
                        <span>What is an OCI? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="two_open">
                       <p>The Overseas Citizenship of India (OCI) is an immigration status permitting a foreign citizen of Indian origin to live and pursue employment in the Republic of India indefinitely.</p>
                    </div>
            </div>
                   
            <div class="step_box wow animate__animated cog_js"  id="three">
                    <a href="javascript:void(0)">
                        <span>Can NRIs buy real estate properties in India? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="three_open">
                      <p> Yes. NRIs can buy and sell residential and commercial properties in India.</p>
                    </div>
            </div>
            
            <div class="step_box wow animate__animated cog_js"  id="four">
                    <a href="javascript:void(0)">
                        <span>Are there any restrictions on the number of properties NRIs can buy in India? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="four_open">
                      <p>There are no restrictions on the number of residential or commercial properties an NRI can own in India. However, the law does prohibit NRIs from purchasing any kind of agricultural land/ plantation property/ farm house in India. </p>
                    </div>
            </div>
            
            <div class="step_box wow animate__animated cog_js"  id="five">
                    <a href="javascript:void(0)">
                        <span> Can NRIs acquire commercial properties in India? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="five_open">
                      <p>Yes, under the general permission granted by the Reserve Bank, property other than agricultural land/farm house/plantation property can be acquired by NRIs provided the purchase consideration is met either out of inward remittances in foreign exchange through normal banking channels or out of funds from the purchaser's NRE/FCNR accounts maintained with banks in India and a declaration is submitted to the Central Office of Reserve Bank in form IPI 7 within a period of 90 days from the date of purchase of the property/final payment of purchase consideration.</p>
                    </div>
            </div>
            
            <div class="step_box wow animate__animated cog_js"  id="six">
                    <a href="javascript:void(0)">
                        <span>Can NRIs buy properties in India without the Reserve Bank’s permission? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="six_open">
                      <p>Reserve Bank has granted general permission to foreign citizens of Indian origin, whether resident in India or abroad, to purchase immovable property in India for their bona fide residential purpose. They are, therefore, not required to obtain permission from the Reserve Bank.      </p>
                    </div>
            </div>
            
            <div class="step_box wow animate__animated cog_js"  id="seven">
                    <a href="javascript:void(0)">
                        <span>Can NRIs obtain loans for acquisition of a house/flat for residential<br> purposes from institutions providing housing finance? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="seven_open">
                      <p> The Reserve Bank has granted some general permission to certain financial institutions providing housing finance e.g. HDFC, LIC Housing Finance Ltd., etc, and authorized dealers to grant housing loans to NRI nationals for acquisition of a NRI house/flat for self-occupation subject to certain conditions. Criteria regarding the purpose of the loan, margin money and the quantum of loan will be at par with those applicable to resident Indians. Repayment of the loan should be made within a period not exceeding 15 years, out of inward remittance through banking channels or out of funds held in the investors' NRE/FCNR/NRO accounts.</p>
                    </div>
            </div>
            
            <div class="step_box wow animate__animated cog_js"  id="eight">
                    <a href="javascript:void(0)">
                        <span>What is the Tax treatment for income generated from property selling or renting for NRI/PIO/OCI? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="eight_open">
                      <p>The mere acquisition of property does not attract income tax. However, any income accruing from the ownership of it, in the form of rent (if it is let out)/annual value of the house (if is not let out and it is not the only residential property owned by that person in India) and/or capital gains (short term or long term) arising on the sale of this house or part thereof is taxable in the hands of the owner.</p>
                    </div>
            </div>
            
            <div class="step_box wow animate__animated cog_js"  id="nine">
                    <a href="javascript:void(0)">
                        <span> How does Double Taxation Avoidance Agreement work in case of NRIs? <img src="images/arrow-tab.svg" alt="Arrow - Central Park"/></span>
                    </a>
                    <div class="step_content" id="nine_open">
                      <p>In case of sale of an immovable property, the Double Tax Avoidance Agreement (DTAA) with most countries state that capital gains will be taxed in the country where the immovable property is situated. Hence, if an NRI owns immovable property in India, then he/she will be subject to pay tax in India on the capital gains which arise on the sale of the property. Similarly, letting of immovable property in India would be taxed in India under most tax treaties.</p>
                    </div>
            </div>
            
            
          
        </div>
      </div>
    </div>
  

      
  <style>
.mainwrap footer .footerinner .footermedia {
    width: 90%;
    float: left;
    position: absolute;
    bottom: 7px;
}l
      .footnavgrid {
    padding-bottom: 38px;
}
img.thererlogos {
    width: 60px;
}
</style>

  <!--Footer-->
        <footer>
            <div class="width90">
                <div class="footerinner">
                     <div class="footerlogo">
                         <div class="footgrid">
                             <div class="footitem">
                                 <div class="flogo">
                                     <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="43"  alt="Central Park Logo">-->
                                     <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="43"  alt="Central Park Logo">
                                 </div>
                             </div>

                             <div class="footitem">
                                <div class="footext">
                                    <p>The Median, Central Park Resorts, Sector – 48, Gurugram, Haryana 122018

 <a class="button map_underline" href="javascript:void(0)" onclick="loadMap('2')" id="map" >View Location Map</a></p>
                                </div>
                            </div>

                            <div class="footitem" >
                                <div class="footext" style="display:none">
                                    <p>Head Office :  <a href="mailto:info@headoffice.com">info@headoffice.com</a></p>
                                    <p>Sales Office : <a href="mailto:info@salesoffice.com">info@salesoffice.com</a></p>
                                </div>
                            </div>

                            <div class="footitem">
                                <a href="https://www.centralpark.in/listing.php">
                                <div class="footprope">
                                    <div class="width90">
                                        <div class="propgrid">
                                            <div class="propitem">
                                                <div class="fproptext">
                                                    <strong>Select A Property</strong>
                                                </div>
                                            </div>
                                            <div class="propitem">
                                                <div class="fproptext">
                                                   <img src="https://www.centralpark.in/images/footerimg.svg" width="60" height="60"  alt="footer icon">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </div>                            
                         </div>
                     </div>

                    <div class="footernav">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Central Park</strong>
                                    <ul>
                                        <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                        <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                        <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                        <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                        <li><a href="https://www.centralpark.in/crystaltown.php">Facility Management</a></li>
                                        <!--<li><a href="https://www.centralpark.in/pdf/CompiledSMCR_CPFV.pdf" target="_blank">Environmental Clearance</a></li>-->
                                    </ul>
                                </div>
                            </div>
                          <div class="footnavitem">
                                 <div class="footernavi">
                                    <strong>About Us</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/about-us.php">Who We Are</a></li>
                                       <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                        <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                       <li><a href="https://www.centralpark.in/blog/">Blogs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>NRI Corner</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/nri-corner.php">Why Central Park</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#whyindia">Why India</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#faq">FAQ's</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Careers</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/careers.php">Join Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Quick Links</strong>
                                    <ul>
                                                                               <li><a href="https://www.centralpark.in/refund-policy.php">Refund Policy</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/privacy-policy.php">Privacy Policy</a></li>
                                                                              <li><a href="https://www.centralpark.in/terms-conditions.php">Terms & Conditions</a></li>
                                       
                                                                           </ul>
                                </div>
                            </div>
                            
<!--                          -->


                            
                            <!--<div class="footnavitem borderrightleft">-->
                            <!--    <div class="width90">-->
                            <!--        <div class="footernavi">-->
                            <!--            <strong style="line-height: 1.2;"> Download Our Newsletter</strong>-->
                            <!--            <p>To stay updated about the ongoing events in the Central Park community and unravel the best of your future, check out our newsletter, The Chronicle. </p>-->
                            <!--            <div class="infileds">-->
                                            
                            <!--                <form class="infileds" action="dataSubscribe.php" method="POST" id="subscribe_form">-->
                            <!--                <input type="text" class="form-email" placeholder="Enter Your Email" id="email_sub" name="email_sub" >-->
                            <!--                <input type="hidden" id="footerPage" value="subscribeForm">-->
                            <!--                <button class="btn btn_submit"  type="submit"><img src="https://www.centralpark.in/images/footer_icon.svg" width="40" height="8"  alt="footer icon"></button>-->
                            <!--                </form>-->
                            <!--            </div>                                      <p id="success2" style="color:green;font-size: 14px;"></p>  -->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
<div class="thereeranumber">
    <p><span>RERA NO.:</span>Mikasa Plot : RC/REP/HARERA/GGM/95 OF 2017/7(3)/32/2023/09, RC/REP/HARERA/GGM/395/127/2020/11, RC/REP/HARERA/GGM/562/294/2022/37 | Fleur Villas: RC/REP/HARERA/GGM/624/356/2022/99 | Aqua Front Towers & The Room: RC/REP/HARERA/GGM/150 OF 2017/7(3)/34/2023/11  | The Orchard: RC/REP/HARERA/GGM/672/404/2023/16 | Bignonia Tower: RC/REP/HARERA/GGM/826/558/2024/53 | Bellavista: RC/REP/HARERA/GGM/379/111/2019/73 | The Selene Tower: RC/REP/HARERA/GGM/964/696/2025/67 | <a href="https://haryanarera.gov.in/" target="_blank">Haryanarera.gov.in</a></p>
</div>
                    <div class="footermedia">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Follow Us</strong>
                                    <ul>
                                        <li><a rel="nofollow" href="https://www.facebook.com/CentralParkIn/" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.instagram.com/centralparkin/"  target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ"  target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                        <!--<li><a rel="nofollow" href="https://twitter.com/CentralParkIn"  target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
                                        <li><a rel="nofollow" href="https://www.linkedin.com/company/central-park-in/"  target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp; ttt</strong>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp;</strong>
                                    <p class="pd-lt40">&copy;Centralpark 2025. All Rights Reserved</p>
                                </div>
                            </div>
                            <input type="hidden" id="is_home" name="is_home" value="https://www.centralpark.in/">
                            <input type="hidden" id="c_page" name="c_page" value="nri-corner.php">
                        </div>
                    </div>
                </div>
            </div>
        </footer>

<!--
        <div class="copyrights">
            <div class="text-center">
                <span><a href="https://cogculture.agency" target="_blank"> <img src="https://www.centralpark.in/images/cclogo.svg" width="22" height="16" alt="cogdigital"></a></span>
            </div>
        </div>
-->
            
        <div id="modal-container-location">
          <div class="modal-background">
            <div class="modal bg-white cnt-modal"  id="ConnectusOpen">
                <a href="javascript:void(0)" class="closebutton" ><img src="https://www.centralpark.in/images/icon-close.svg" width="17" height="17" alt="Central Park Icon Close"></a>
                
                <div class="width90" >
                <iframe src=""  id="Connectus"  style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
          </div>
          </div>
          
        
    </div>
    
    <input type="hidden" value="nri-corner.php" id="is_home">
    
       
    <script src="https://www.centralpark.in/js/jquery.min.js"></script>    
    <script src="https://www.centralpark.in/js/wow.min.js"></script>
    <script src="https://www.centralpark.in/js/slick.js"></script>
    <script src="https://www.centralpark.in/js/eocjs-newsticker.js"></script>
    
    <script src="https://www.centralpark.in/js/gsap.js" defer ></script>
    <script src="https://www.centralpark.in/js/ScrollTrigger.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollMagic.js" defer></script>
    <script src="https://www.centralpark.in/js/animation.gsap.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollToPlugin.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@17.6.1/dist/lazyload.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/additional-methods.js"></script>
    <!--<script src='https://unpkg.com/axios/dist/axios.min.js'></script>-->
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.0.0-alpha.1/axios.min.js"></script>-->
    <script src="https://www.centralpark.in/js/validation.js"></script>
    <script src="https://www.centralpark.in/js/custom.js"></script>
  
    <script>
        $(document).ready(function(){
            $("#slidetext").eocjsNewsticker({
                speed: 20,
                timeout: 1,
                divider: '',
                type: 'static'
            });
            
            // $.ajax({
            // 		url:"https://www.centralpark.in/aqi.php",
            // 		method:"GET",
            // 		success:function(response){
            // 		    var res = jQuery.parseJSON(response)
            //                  $('#resort_aqi').html(res.aqi_1)
            //                  $('#sohna_road_aqi').html(res.aqi_2)
            // 		}
            // });

        });
        
        // (function test() {

        //     axios({
        //       "async": true,
        //       "crossDomain": true,
        //       "url": "https://production.oizom.com/v1/data/cur",
        //       "method": "GET",
        //       "headers": {
        //         "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwNzAsIm9yZ0lkIjoiQ1AyMDE5MDUwMSIsInVzZXJFbWFpbCI6ImNwMjAxOTA1MDFAb2l6b20uY29tIiwiaWF0IjoxNjU2NjY4OTY3LCJleHAiOjE2ODgyMDQ5NjcsImlzcyI6IkNWSm9HdUgwZWhRRzViZEhyMzg3Y0tPZ1Nra3BOcGRsIn0.8xkfajwKv7_-M1AvNi6sK9MDXn4jSngjPt0ahjGjDIM",
        //         "cache-control": "no-cache",
        //         "postman-token": "30042871-ce0e-2dd5-dcd8-5635ec6ec140"
        //       }
        //     }).then(function(response) {
        //                     $('#resort_aqi').html(response.data[0].aqi)
        //                     $('#sohna_road_aqi').html(response.data[1].aqi)
        //                 })

        // })();
    
    </script>   
   <script>
  gtag('event', 'conversion', {'send_to': 'AW-16495080556/Dv0oCKTs3aIZEOzou7k9'});
</script>

<script>
  window.addEventListener('load', function() {
    if(window.location.pathname==("/") && window.document.referrer.includes("thanks.php")){
      gtag('event', 'conversion', {'send_to': 'AW-16495080556/7JrQCKHs3aIZEOzou7k9'});
    }
  });
</script>

<script>
  (function(){
    document.addEventListener('click', function(e){
      if(e.target.closest('a[href^="tel:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/IHfTCKfs3aIZEOzou7k9'});
      }
      if(e.target.closest('a[href^="mailto:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/yPy_CKrs3aIZEOzou7k9'});
      }
    });
  })();
</script>
   
   <script>
    function loadMap(v){
      if(v=="1")
        var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3506.9840833843336!2d77.10016661436981!3d28.48002598247817!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf47ab06242fb836a!2sGLOBAL%20BUSINESS%20PARK!5e0!3m2!1sen!2sin!4v1622103095919!5m2!1sen!2sin";
          
      if(v=="2")
        //   var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3508.830867361511!2d77.03224111507788!3d28.424359882500486!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbd478862f690aeca!2sCentral+Park+The+Resort!5e0!3m2!1sen!2sin!4v1530170396691";
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2481.144333967807!2d77.03577665122448!3d28.423240585612685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1878dee37f57%3A0xa9ecdd7d72782cf6!2sCentral%20Park%C2%AE!5e0!3m2!1sen!2sin!4v1649670949376!5m2!1sen!2sin";
            
            
            if(v=="3")
    
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
            
              
      if(v=="5")
           var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
      
       if(v=="6")
           var loc ="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3511.281450826602!2d77.06318704995007!3d28.350339303463272!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d233202703f8f%3A0x6069d5f67eb02f07!2sThe%20Room!5e0!3m2!1sen!2sin!4v1626854192717!5m2!1sen!2sin";
           
        if(v=="4")
          var loc = "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14035.267568735091!2d77.0347599!3d28.4247815!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x57c9a489284d2d27!2sBella%20Vista!5e0!3m2!1sen!2sin!4v1646810366352!5m2!1sen!2sin";
      
      document.getElementById("Connectus").setAttribute('src', loc);
      $('.wellnes-open').css("transform", "translate(0px, 0%)")  
      }
      function closeBtn(a){
         $('#ConnectusOpen').css("transform", "translate(0px, 100%)")
         document.getElementById("Connectus").setAttribute('src','');
      }
      
</script>
 <script>
//     $(".thebuttonnsd button").click(function () {
//     $(".cookiesaccept").css("display", "none");
// });
// </script>
 <script>
// // Function to set a cookie with a 1-day expiration
// function setCookie(name, value, days) {
//     var date = new Date();
//     date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
//     var expires = "expires=" + date.toUTCString();
//     document.cookie = name + "=" + value + ";" + expires + ";path=/";
// }

// // Add event listener to button
// document.getElementById('setCookieBtn').addEventListener('click', function() {
//     setCookie('myCookie', 'cookieValue', 1); // Set cookie for 1 day
//     alert('Cookie set for 1 day!');
// });
// </script>

<script>
    // Function to set a cookie with a specified expiration in days
    function setCookie(name, value, days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
        var expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    // Function to get a specific cookie by name
    function getCookie(name) {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.indexOf(name + "=") == 0) {
                return cookie.substring(name.length + 1);
            }
        }
        return "";
    }

    // Function to hide the cookie notice
    function hideCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'none';
    }

    // Function to show the cookie notice
    function showCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'block';
    }

    // Add event listener for 'Accept All' button
    document.getElementById('setCookieBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'true', 1); // Set cookie for 1 day
        hideCookieNotice(); // Hide cookie notice after acceptance
    });

    // Add event listener for 'Reject All' button (optional behavior)
    document.getElementById('rejectCookiesBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'false', 1); // Set rejection cookie
        hideCookieNotice(); // Hide cookie notice after rejection
    });

    // Function to check if the cookie is already set
    function checkCookie() {
        var acceptedCookies = getCookie('acceptedCookies');
        if (acceptedCookies === 'true') {
            hideCookieNotice(); // If cookies were accepted, hide the notice
        } else {
            showCookieNotice(); // If no cookie or rejected, show the notice
        }
    }

    // Run the checkCookie function on page load
    window.onload = checkCookie;
    </script>
     <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script>
    var swiper = new Swiper(".mySwipertest", {
      slidesPerView: 3,
      spaceBetween: 30,
    //   loop:true,
      autoplay: {
        delay: 50500,
        disableOnInteraction: false,
      },
        breakpoints: {
              320: {
          slidesPerView: 1,
          spaceBetween: 20,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 40,
        },
        1024: {
          slidesPerView: 3,
          spaceBetween: 50,
        },
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });
  </script>
</body>
</html> 

