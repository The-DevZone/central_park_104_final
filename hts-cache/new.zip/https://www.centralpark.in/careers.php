    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#ffffff">
        <title>Careers at Central Park: Join a Reliable Real Estate Company in Gurgaon</title>
    <meta name="description" content="Explore career opportunities at Central Park, one of the most reliable real estate companies in Gurgaon. Be part of a team focused on delivering trust, growth, and customer satisfaction.">
    <meta name="keywords" content="Real Estate Jobs, Jobs in Central Park Resorts.">
    <meta name="robots" content="noodp">
    <meta property="og:title" content="Careers at Central Park: Join a Reliable Real Estate Company in Gurgaon">
    <meta property="og:site_name" content="Central Park - Luxury housing">
    <meta property="og:url" content="https://www.centralpark.in/careers.php">
    <meta property="og:description" content="Explore career opportunities at Central Park, one of the most reliable real estate companies in Gurgaon. Be part of a team focused on delivering trust, growth, and customer satisfaction.">
    <meta property="og:image" content="https://www.centralpark.in/images/logo.png">
    <meta name="twitter:title" content="Careers at Central Park: Join a Reliable Real Estate Company in Gurgaon">
    <meta name="twitter:description" content="Explore career opportunities at Central Park, one of the most reliable real estate companies in Gurgaon. Be part of a team focused on delivering trust, growth, and customer satisfaction.">
    <meta name="twitter:image" content="https://www.centralpark.in/images/logo.png">
    
        <link rel="canonical" href="https://www.centralpark.in/careers.php">
        
    
    <!--Schema Tags-->
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Central Park",
  "url": "https://www.centralpark.in/",
  "logo": "https://www.centralpark.in/images/logo2.svg",
  "sameAs": [  
    "https://www.facebook.com/CentralParkIn/",    
    "https://twitter.com/CentralParkIn",
    "https://www.instagram.com/centralparkin/",
    "https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ",
    "https://www.linkedin.com/company/central-park-in/",
    "https://www.centralpark.in/"
  ]
}
</script>    <!--Stylecss-->
    
    <link rel="icon" type="image/x-icon" href="https://www.centralpark.in/images/faviv2.ico">
    <link rel="stylesheet" href="https://www.centralpark.in/css/style.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/responisve.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/animate.css"> 
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick-theme.css">  
    <link rel="stylesheet" href="https://www.centralpark.in/css/eocjs-newsticker.css">
   <link rel="stylesheet" href="https://www.centralpark.in/css/font-awesome.min.css">
   <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.0/css/all.min.css" integrity="sha512-9xKTRVabjVeZmc+GUW8GgSmcREDunMM+Dt/GrzchfN8tkwHizc5RP4Ok/MXFFy5rIjJjzhndFScTceq5e6GvVQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />-->
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/OPTIMA.woff" type="font/woff" crossorigin="anonymous">
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/fontawesome-webfont.woff2?v=4.7.0" type="font/woff2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />--><!-- Facebook Pixel Code -->

<script>


!function(f,b,e,v,n,t,s)



{if(f.fbq)return;n=f.fbq=function(){n.callMethod?



n.callMethod.apply(n,arguments):n.queue.push(arguments)};



if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';



n.queue=[];t=b.createElement(e);t.async=!0;



t.src=v;s=b.getElementsByTagName(e)[0];



s.parentNode.insertBefore(t,s)}(window,document,'script',



'https://connect.facebook.net/en_US/fbevents.js');



fbq('init', '394540540386962');



fbq('track', 'PageView');


</script>

<noscript>

<img height="1" width="1"

src="https://www.facebook.com/tr?id=394540540386962&ev=PageView

&noscript=1"/>

</noscript>

<!-- End Facebook Pixel Code -->

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K5WV3Q');</script>
<!-- End Google Tag Manager -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-60041058-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-60041058-1');
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16495080556"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-16495080556');
</script>

<script>
  gtag('config', 'AW-16495080556/znPoCOHsm6UZEOzou7k9', {
    'phone_conversion_number': '+91 7065777702'
  });
</script>

<!-- Taboola Pixel Code -->
<!--<script type='text/javascript'>
  window._tfa = window._tfa || [];
  window._tfa.push({notify: 'event', name: 'page_view', id: 1429034});
  !function (t, f, a, x) {
         if (!document.getElementById(x)) {
            t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f);
         }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/unip/1429034/tfa.js',
  'tb_tfa_script');
</script>-->
<!-- End of Taboola Pixel Code -->


</head>

<body>
    
    <style>
        
        header {
    background: #00000014;
}
    </style>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K5WV3Q"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!-- Event snippet for Website Traffic views conversion page -->


    <div class="jsOverlay"></div>
    <div class="mainwrap">
            <style>
            span.s__0999 {
    background: transparent!important;
    font-size: 42px;
    color: #9e8061;
}
      
      .mainwrap .hospitalitysection .hospiinner {
    width: 100%;
    float: left;
    padding: 63px 0;
}      
     body.black_bg .logo-white {
    display: block;
}
            .mainwrap header .navigation .left .logo img {
   
    top: 0px!important;
}  
            
            .banner-caption {
    margin: auto;
    padding: 146px 0 13px;
    text-align: center;
}
            
            .valley_prallax .h3 {
    margin-bottom: 34px;
}  
            .valley_prallax {
    padding-top: 148px;
}
</style>
        <header>  
            <div class="navigation">
                <div class="width90">
                    <div class="left">
                        <div class="logo d-flex">
                            <a href="https://www.centralpark.in/" class="">
                                <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="49" class="logo-white lazy" alt="Central Park Logo">-->
                                <!--<img src="https://www.centralpark.in/images/logo2.svg" width="227" height="49" class="logo-black lazy" alt="Central Park Logo">-->
                                <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="49" class="logo-white lazy" alt="Central Park Logo">
                            </a>
                                                        <img src="https://www.centralpark.in/images/20-Years.svg" width="34" height="62" class="years20 lazy" alt="Central Park - 20 Years of curating a privileged lifestyle">
                                                    </div>
                    </div>
                    <div class="right">
                        <div class="headernav">
                            <div class="navtoggle opennav">
                                <a href="javascript:void(0)" title="Open">
                                    <span></span>
                                    <span></span>
                                </a>
                            </div>
                            <div class="topsmnav">
                                <ul>
                                    <!--<li><a href="https://www.centralpark.in/pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                    <li><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></li>
                                    <!--<li><a href="javascript:void(0)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">-->
                                    <!--    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>-->
                                    <!--  </svg></a></li>-->
                                </ul>
                            </div>
                            <div class="mainnav">
                                <ul>
                                    <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                    <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                    <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                    <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                </ul>
                            </div>                            
                        </div>
                    </div>
                </div>
                <div class="windowheightnav">
                    <div class="navclose closenav">
                        <a href="javascript:void(0)" title="Close">
                            <span class="s__0999">x</span>  
                        </a>
                    </div>
                    <div class="windogrid">
                        <div class="lrsection">
                            <div class="parknavbar">
                                 <div class="width70">
                                     
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/residential.php">Residential</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/commercial.php">Commercial</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></strong>
                                    </div>
                                    
                                     <div class="innernavbar">
                                         <span>&nbsp;</span>
                                         <strong><a href="https://www.centralpark.in/about-us.php">About Us</a></strong>
                                         <ul>
                                             <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#team">LEADERSHIP</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                         </ul>
                                     </div>

                                     <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/group.php">Group</a></strong>
                                        <ul>
                                            <li><a href="https://www.centralpark.in/group.php#automotive">Automotive</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#infrastructure">Infrastructure</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#education">Education</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#hospitality">Hospitality</a></li>
                                        </ul> 
                                    </div>

                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/media.php">Media</a></strong>
                                         <ul>
                                            <li><a href="https://www.centralpark.in/media.php#tab1" onClick="loadmr('1');">News Coverage </a></li>
                                            <li><a href="https://www.centralpark.in/media.php#tab2" onClick="loadmr('2');">VIDEO GALLERY</a></li>
                                        </ul> 
                                    </div>
                                    
                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></strong>
                                    </div>
                                    
                                    <div class="d-none top-menu-headr">
                                        <ul class="small-menu_list">
                                            <!--<li><a href="pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                        </ul>
                                    </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        
        
      <div class="popup custom-popup" data-popup="popup-1">
    <div class="popup-inner">
        <h2>Enquire Now</h2>
        
        <div class="pd100  contact-wrapper">
       
                <div class="form">
                    <p id="success_1" style="color: green;font-size: 14px;"></p>
                    <p id="reCaptchaError_1" style="color:red;"></p>
                    <form action="enquireData.php" method="POST" id="enquire_now_form">
                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control let" placeholder="Name" name="enquire_now_name" id="enquire_now_name">
                        </div>
                        <div class="form-group w50 lt-50">
                           <input type="text" class="form-control" placeholder="Email"  name="enquire_now_email" id="enquire_now_email">
                        </div>

                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control" placeholder="Phone Number" name="enquire_now_phone" id="enquire_now_phone" maxlength="10" onkeypress="return isNumberKey(event,this)">
                        </div>
                        
                        <div class="form-group w50 lt-50">
                            <select class="form-control" name="enquire_now_project" id="enquire_now_project">
                              <option value="">Select Projects</option>
                              <option value="Aqua Front Tower&Central Park Flower Valley">Aqua Front Tower</option>
                              <option value="Central Park Flower Valley&Central Park Flower Valley">Central Park Flower Valley</option>
                              <option value="Cerise Floors&Central Park Flower Valley">Cerise Floors</option>
                              <option value="Clover Floors&Central Park Flower Valley">Clover Floors</option>
                              <option value="Flamingo Floors&Central Park Flower Valley">Flamingo Floors</option>
                              <option value="Fleur Villa&Central Park Flower Valley">Fleur Villa</option>
                              <option value="Mikasa&Central Park Flower Valley">Mikasa</option>
                              <option value="The Room - Flower Valley&Central Park Flower Valley">The Room - Flower Valley</option>
                              <option value="Beau Villas&Central Park Resorts">Beau Villas</option>
                              <option value="Belgravia Apartments&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Bellavista&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Central Park Resorts&Central Park Resorts">Central Park Resorts</option>
                              <option value="The Room&Central Park Resorts">The Room</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                           <textarea  class="form-control" placeholder="Message" name="enquire_now_msg" id="enquire_now_msg" rows="1"></textarea>
                        </div>
                        <input type="hidden" name="page_source" value="">

                      
                        
                        <button class="btn btn_submit btnSubmit"  type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72">
                                <defs>
                                    <style>
                                        .cls-1 {
                                            fill: none;
                                            stroke: #9e8061;
                                            stroke-miterlimit: 10;
                                        }
                                    </style>
                                </defs>
                                <g id="Layer_10" data-name="Layer 2">
                                    <g id="Layer_1-10" data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"></path></g>
                                </g>
                            </svg>
                            <span>Submit<b class="upcom"></b></span> 
                        </button>
                    </form>
                </div>
            </div>
            
        

        
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
    </div>
</div>  <style>
    #fileupload-error {
    color: red;
    font-size: 12px !important;
    margin-top: 10px;
    display: block;
    font-family: 'Optima';
    margin-bottom: 10px;
    letter-spacing: 1px;
    }
</style>
<div class="banner">
    <div class="width90">
        <div class="banner-caption">
            <div class="text-center">
                <span>CAREERS AT CENTRAL PARK</span>
            </div>
            <h1>New chapter in your career</h1>
        </div>
        <div class="breadcrumbslist wow animate__animated cog_js animated">
                <ul>
                    <li><a href="https://www.centralpark.in/">Home</a></li>
                    <li>Careers</li>
                </ul>
            </div>
        <div class="prallax-cp hover_effect">
            <div class="bg_img active" id="careers_open1" style="background:url('images/careers1.jpg') no-repeat right"></div>
            <div class="bg_img" id="careers_open2" style="background:url('images/careers6.jpg') no-repeat right"></div>
            <div class="bg_img" id="careers_open3" style="background:url('images/careers3.jpg') no-repeat right"></div>
            <div class="bg_img" id="careers_open4" style="background:url('images/careers4.jpg') no-repeat right"></div>
            <div class="bg_img" id="careers_open5" style="background:url('images/careers5.jpg') no-repeat right"></div>
            <div class="bg_img" id="careers_open6" style="background:url('images/careers2.jpg') no-repeat right"></div>
           <ul class="car">
                <li id="careers1" class="borde-bottom ">
                    <h2>Culture <br>
                        <span>At Central Park, we encourage people to explore their talents and live up to their fullest potential. Our team believes in growing together and supporting one another through arduous times. </span>
                    </h2>
                </li>
                <li id="careers2" class="borde-bottom"><h2>Healthy Work Environment <br> <span>We believe that a company will only function at its fullest if the employees are happy and healthy. We always put the work environment on the top of our priority list and use insights provided by our employees to their benefit by creating a salubrious atmosphere. </span></h2></li>
                <li id="careers3" class="border_bottom"><h2>Recognition and Appreciation <br> <span>Hard work is never overlooked by us. We are firm believers of appreciating one’s caliber with moral incentives. It performs as a morale boost and increased productivity of the employees. We fathom the endeavours one goes through to deliver standard work and when we see it, we know it.</span></h2></li>
                <li id="careers4" class="border_right"><h2>Transparent Functioning <br><span>We believe transparency is the key to an honest system. We stand up to our promises and maintain an ingenious corporate relationship with our employees and clients</span></h2></li>
                <li id="careers5" class="border_right"><h2>Culturally Rich <br> <span>We are inclusive of all cultures. You will find a diverse workforce within the system that will broaden your horizons and enlighten you in different ways beyond your existing beliefs and principles.</span></h2></li>
                <li id="careers6"><h2>Consistent Guidance <br> <span>We can assure that you will never find yourself lost in the system. We will always have your back and assistance will be consistently provided to you by your seniors. We emphasize on the fact that innovation and creativity flourish within a system when hindrances are faced as a joint force. </span></h2></li>
            </ul>
            
        </div>
        
        <div class="para_content">
            <!--<h2 class="h2 wow animate__animated animate__fadeInUp">Why Central Park?</h2>-->

            <p class="wow animate__animated cog_js">
               Explore your talents with us where you'll find an abundance of opportunities to grow and flourish. As we tread on extravagance of virtue, innovation driven by human ingenuity continues to be our principal belief.
            </p>
        </div>
    </div>
    <!--width90-->
</div>

<div class="pd100 contact-wrapper">
    <div class="width90">
        <div class="row">
            <div class="col-md-6">
                <div class="add">
                    <div class="title">
                        <h2 class="wow animate__ animate__fadeInUp">
                            Apply 
                            and join<br />
                            the
                            action
                        </h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form wow animate__ animate__fadeInUp">
                    
                    <p id="success" style="text-align: center; color: green;"></p>
                    <form method="POST" action="https://www.centralpark.in/insertcareer.php" id="careerform" enctype="multipart/form-data">

                        <div class="form-group">
                            <input type="text" class="form-control let" placeholder="Name" name="name" id="name" />
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Email" name="email" id="email" />
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Phone Number" name="phone_number" id="phone_number" maxlength="10" onkeypress="return isNumberKey(event,this)" />
                        </div>

                        <div class="form-group">
                            <textarea type="text" class="form-control" placeholder="Message" name="msg" id="msg" rows="1"></textarea>
                        </div>
                        <div class="form-group file-upload">
                            <label>Upload Resume</label>
                            <input type="file" name="fileupload" class="form-control" />
                        </div>

                        <button class="btn btn_submit" type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72">
                                <defs>
                                    <style>
                                        .cls-1 {
                                            fill: none;
                                            stroke: #9e8061;
                                            stroke-miterlimit: 10;
                                        }
                                    </style>
                                </defs>
                                <g id="Layer_2" data-name="Layer 2">
                                    <g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"></path></g>
                                </g>
                            </svg>
                            <span>Submit<b class="upcom"></b></span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

      
  <style>
.mainwrap footer .footerinner .footermedia {
    width: 90%;
    float: left;
    position: absolute;
    bottom: 7px;
}l
      .footnavgrid {
    padding-bottom: 38px;
}
img.thererlogos {
    width: 60px;
}
</style>

  <!--Footer-->
        <footer>
            <div class="width90">
                <div class="footerinner">
                     <div class="footerlogo">
                         <div class="footgrid">
                             <div class="footitem">
                                 <div class="flogo">
                                     <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="43"  alt="Central Park Logo">-->
                                     <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="43"  alt="Central Park Logo">
                                 </div>
                             </div>

                             <div class="footitem">
                                <div class="footext">
                                    <p>The Median, Central Park Resorts, Sector – 48, Gurugram, Haryana 122018

 <a class="button map_underline" href="javascript:void(0)" onclick="loadMap('2')" id="map" >View Location Map</a></p>
                                </div>
                            </div>

                            <div class="footitem" >
                                <div class="footext" style="display:none">
                                    <p>Head Office :  <a href="mailto:info@headoffice.com">info@headoffice.com</a></p>
                                    <p>Sales Office : <a href="mailto:info@salesoffice.com">info@salesoffice.com</a></p>
                                </div>
                            </div>

                            <div class="footitem">
                                <a href="https://www.centralpark.in/listing.php">
                                <div class="footprope">
                                    <div class="width90">
                                        <div class="propgrid">
                                            <div class="propitem">
                                                <div class="fproptext">
                                                    <strong>Select A Property</strong>
                                                </div>
                                            </div>
                                            <div class="propitem">
                                                <div class="fproptext">
                                                   <img src="https://www.centralpark.in/images/footerimg.svg" width="60" height="60"  alt="footer icon">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </div>                            
                         </div>
                     </div>

                    <div class="footernav">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Central Park</strong>
                                    <ul>
                                        <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                        <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                        <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                        <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                        <li><a href="https://www.centralpark.in/crystaltown.php">Facility Management</a></li>
                                        <!--<li><a href="https://www.centralpark.in/pdf/CompiledSMCR_CPFV.pdf" target="_blank">Environmental Clearance</a></li>-->
                                    </ul>
                                </div>
                            </div>
                          <div class="footnavitem">
                                 <div class="footernavi">
                                    <strong>About Us</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/about-us.php">Who We Are</a></li>
                                       <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                        <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                       <li><a href="https://www.centralpark.in/blog/">Blogs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>NRI Corner</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/nri-corner.php">Why Central Park</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#whyindia">Why India</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#faq">FAQ's</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Careers</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/careers.php">Join Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Quick Links</strong>
                                    <ul>
                                                                               <li><a href="https://www.centralpark.in/refund-policy.php">Refund Policy</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/privacy-policy.php">Privacy Policy</a></li>
                                                                              <li><a href="https://www.centralpark.in/terms-conditions.php">Terms & Conditions</a></li>
                                       
                                                                           </ul>
                                </div>
                            </div>
                            
<!--                          -->


                            
                            <!--<div class="footnavitem borderrightleft">-->
                            <!--    <div class="width90">-->
                            <!--        <div class="footernavi">-->
                            <!--            <strong style="line-height: 1.2;"> Download Our Newsletter</strong>-->
                            <!--            <p>To stay updated about the ongoing events in the Central Park community and unravel the best of your future, check out our newsletter, The Chronicle. </p>-->
                            <!--            <div class="infileds">-->
                                            
                            <!--                <form class="infileds" action="dataSubscribe.php" method="POST" id="subscribe_form">-->
                            <!--                <input type="text" class="form-email" placeholder="Enter Your Email" id="email_sub" name="email_sub" >-->
                            <!--                <input type="hidden" id="footerPage" value="subscribeForm">-->
                            <!--                <button class="btn btn_submit"  type="submit"><img src="https://www.centralpark.in/images/footer_icon.svg" width="40" height="8"  alt="footer icon"></button>-->
                            <!--                </form>-->
                            <!--            </div>                                      <p id="success2" style="color:green;font-size: 14px;"></p>  -->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
<div class="thereeranumber">
    <p><span>RERA NO.:</span>Mikasa Plot : RC/REP/HARERA/GGM/95 OF 2017/7(3)/32/2023/09, RC/REP/HARERA/GGM/395/127/2020/11, RC/REP/HARERA/GGM/562/294/2022/37 | Fleur Villas: RC/REP/HARERA/GGM/624/356/2022/99 | Aqua Front Towers & The Room: RC/REP/HARERA/GGM/150 OF 2017/7(3)/34/2023/11  | The Orchard: RC/REP/HARERA/GGM/672/404/2023/16 | Bignonia Tower: RC/REP/HARERA/GGM/826/558/2024/53 | Bellavista: RC/REP/HARERA/GGM/379/111/2019/73 | The Selene Tower: RC/REP/HARERA/GGM/964/696/2025/67 | <a href="https://haryanarera.gov.in/" target="_blank">Haryanarera.gov.in</a></p>
</div>
                    <div class="footermedia">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Follow Us</strong>
                                    <ul>
                                        <li><a rel="nofollow" href="https://www.facebook.com/CentralParkIn/" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.instagram.com/centralparkin/"  target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ"  target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                        <!--<li><a rel="nofollow" href="https://twitter.com/CentralParkIn"  target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
                                        <li><a rel="nofollow" href="https://www.linkedin.com/company/central-park-in/"  target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp; ttt</strong>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp;</strong>
                                    <p class="pd-lt40">&copy;Centralpark 2025. All Rights Reserved</p>
                                </div>
                            </div>
                            <input type="hidden" id="is_home" name="is_home" value="https://www.centralpark.in/">
                            <input type="hidden" id="c_page" name="c_page" value="careers.php">
                        </div>
                    </div>
                </div>
            </div>
        </footer>

<!--
        <div class="copyrights">
            <div class="text-center">
                <span><a href="https://cogculture.agency" target="_blank"> <img src="https://www.centralpark.in/images/cclogo.svg" width="22" height="16" alt="cogdigital"></a></span>
            </div>
        </div>
-->
            
        <div id="modal-container-location">
          <div class="modal-background">
            <div class="modal bg-white cnt-modal"  id="ConnectusOpen">
                <a href="javascript:void(0)" class="closebutton" ><img src="https://www.centralpark.in/images/icon-close.svg" width="17" height="17" alt="Central Park Icon Close"></a>
                
                <div class="width90" >
                <iframe src=""  id="Connectus"  style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
          </div>
          </div>
          
        
    </div>
    
    <input type="hidden" value="careers.php" id="is_home">
    
       
    <script src="https://www.centralpark.in/js/jquery.min.js"></script>    
    <script src="https://www.centralpark.in/js/wow.min.js"></script>
    <script src="https://www.centralpark.in/js/slick.js"></script>
    <script src="https://www.centralpark.in/js/eocjs-newsticker.js"></script>
    
    <script src="https://www.centralpark.in/js/gsap.js" defer ></script>
    <script src="https://www.centralpark.in/js/ScrollTrigger.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollMagic.js" defer></script>
    <script src="https://www.centralpark.in/js/animation.gsap.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollToPlugin.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@17.6.1/dist/lazyload.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/additional-methods.js"></script>
    <!--<script src='https://unpkg.com/axios/dist/axios.min.js'></script>-->
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.0.0-alpha.1/axios.min.js"></script>-->
    <script src="https://www.centralpark.in/js/validation.js"></script>
    <script src="https://www.centralpark.in/js/custom.js"></script>
  
    <script>
        $(document).ready(function(){
            $("#slidetext").eocjsNewsticker({
                speed: 20,
                timeout: 1,
                divider: '',
                type: 'static'
            });
            
            // $.ajax({
            // 		url:"https://www.centralpark.in/aqi.php",
            // 		method:"GET",
            // 		success:function(response){
            // 		    var res = jQuery.parseJSON(response)
            //                  $('#resort_aqi').html(res.aqi_1)
            //                  $('#sohna_road_aqi').html(res.aqi_2)
            // 		}
            // });

        });
        
        // (function test() {

        //     axios({
        //       "async": true,
        //       "crossDomain": true,
        //       "url": "https://production.oizom.com/v1/data/cur",
        //       "method": "GET",
        //       "headers": {
        //         "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwNzAsIm9yZ0lkIjoiQ1AyMDE5MDUwMSIsInVzZXJFbWFpbCI6ImNwMjAxOTA1MDFAb2l6b20uY29tIiwiaWF0IjoxNjU2NjY4OTY3LCJleHAiOjE2ODgyMDQ5NjcsImlzcyI6IkNWSm9HdUgwZWhRRzViZEhyMzg3Y0tPZ1Nra3BOcGRsIn0.8xkfajwKv7_-M1AvNi6sK9MDXn4jSngjPt0ahjGjDIM",
        //         "cache-control": "no-cache",
        //         "postman-token": "30042871-ce0e-2dd5-dcd8-5635ec6ec140"
        //       }
        //     }).then(function(response) {
        //                     $('#resort_aqi').html(response.data[0].aqi)
        //                     $('#sohna_road_aqi').html(response.data[1].aqi)
        //                 })

        // })();
    
    </script>   
   <script>
  gtag('event', 'conversion', {'send_to': 'AW-16495080556/Dv0oCKTs3aIZEOzou7k9'});
</script>

<script>
  window.addEventListener('load', function() {
    if(window.location.pathname==("/") && window.document.referrer.includes("thanks.php")){
      gtag('event', 'conversion', {'send_to': 'AW-16495080556/7JrQCKHs3aIZEOzou7k9'});
    }
  });
</script>

<script>
  (function(){
    document.addEventListener('click', function(e){
      if(e.target.closest('a[href^="tel:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/IHfTCKfs3aIZEOzou7k9'});
      }
      if(e.target.closest('a[href^="mailto:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/yPy_CKrs3aIZEOzou7k9'});
      }
    });
  })();
</script>
   
   <script>
    function loadMap(v){
      if(v=="1")
        var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3506.9840833843336!2d77.10016661436981!3d28.48002598247817!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf47ab06242fb836a!2sGLOBAL%20BUSINESS%20PARK!5e0!3m2!1sen!2sin!4v1622103095919!5m2!1sen!2sin";
          
      if(v=="2")
        //   var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3508.830867361511!2d77.03224111507788!3d28.424359882500486!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbd478862f690aeca!2sCentral+Park+The+Resort!5e0!3m2!1sen!2sin!4v1530170396691";
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2481.144333967807!2d77.03577665122448!3d28.423240585612685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1878dee37f57%3A0xa9ecdd7d72782cf6!2sCentral%20Park%C2%AE!5e0!3m2!1sen!2sin!4v1649670949376!5m2!1sen!2sin";
            
            
            if(v=="3")
    
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
            
              
      if(v=="5")
           var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
      
       if(v=="6")
           var loc ="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3511.281450826602!2d77.06318704995007!3d28.350339303463272!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d233202703f8f%3A0x6069d5f67eb02f07!2sThe%20Room!5e0!3m2!1sen!2sin!4v1626854192717!5m2!1sen!2sin";
           
        if(v=="4")
          var loc = "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14035.267568735091!2d77.0347599!3d28.4247815!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x57c9a489284d2d27!2sBella%20Vista!5e0!3m2!1sen!2sin!4v1646810366352!5m2!1sen!2sin";
      
      document.getElementById("Connectus").setAttribute('src', loc);
      $('.wellnes-open').css("transform", "translate(0px, 0%)")  
      }
      function closeBtn(a){
         $('#ConnectusOpen').css("transform", "translate(0px, 100%)")
         document.getElementById("Connectus").setAttribute('src','');
      }
      
</script>
 <script>
//     $(".thebuttonnsd button").click(function () {
//     $(".cookiesaccept").css("display", "none");
// });
// </script>
 <script>
// // Function to set a cookie with a 1-day expiration
// function setCookie(name, value, days) {
//     var date = new Date();
//     date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
//     var expires = "expires=" + date.toUTCString();
//     document.cookie = name + "=" + value + ";" + expires + ";path=/";
// }

// // Add event listener to button
// document.getElementById('setCookieBtn').addEventListener('click', function() {
//     setCookie('myCookie', 'cookieValue', 1); // Set cookie for 1 day
//     alert('Cookie set for 1 day!');
// });
// </script>

<script>
    // Function to set a cookie with a specified expiration in days
    function setCookie(name, value, days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
        var expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    // Function to get a specific cookie by name
    function getCookie(name) {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.indexOf(name + "=") == 0) {
                return cookie.substring(name.length + 1);
            }
        }
        return "";
    }

    // Function to hide the cookie notice
    function hideCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'none';
    }

    // Function to show the cookie notice
    function showCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'block';
    }

    // Add event listener for 'Accept All' button
    document.getElementById('setCookieBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'true', 1); // Set cookie for 1 day
        hideCookieNotice(); // Hide cookie notice after acceptance
    });

    // Add event listener for 'Reject All' button (optional behavior)
    document.getElementById('rejectCookiesBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'false', 1); // Set rejection cookie
        hideCookieNotice(); // Hide cookie notice after rejection
    });

    // Function to check if the cookie is already set
    function checkCookie() {
        var acceptedCookies = getCookie('acceptedCookies');
        if (acceptedCookies === 'true') {
            hideCookieNotice(); // If cookies were accepted, hide the notice
        } else {
            showCookieNotice(); // If no cookie or rejected, show the notice
        }
    }

    // Run the checkCookie function on page load
    window.onload = checkCookie;
    </script>
     <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script>
    var swiper = new Swiper(".mySwipertest", {
      slidesPerView: 3,
      spaceBetween: 30,
    //   loop:true,
      autoplay: {
        delay: 50500,
        disableOnInteraction: false,
      },
        breakpoints: {
              320: {
          slidesPerView: 1,
          spaceBetween: 20,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 40,
        },
        1024: {
          slidesPerView: 3,
          spaceBetween: 50,
        },
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });
  </script>
</body>
</html>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.min.js"></script>

<script type="text/javascript">

$(document).ready(function(){
    
       $.validator.addMethod("customemail", 
        function(value, element) {
        return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value);}, 
        "Please enter valid email" );
         $.validator.addMethod("customphone", function(value, element) {
        return /^\d{10}$/.test(value);}, 
        "Please enter 10 digit mobile number");
       
    var insertForm = $("#careerform");
   
    var validator = insertForm.validate({
        
       rules:{
            name :{ required : true },
            email : { required : true, customemail : true },
            phone_number :{ required : true, customphone: true },
            msg : { required : true},
            fileupload : { required : true, extension: "pdf"},
        },
        messages:{
            name :{ required : "This field is required" },
            email : { required : "This field is required", customemail : "Please enter valid email" },
            phone_number :{ required : "This field is required", customphone: "Please enter 10 digit phone number" },
            msg : { required : "This field is required"},
            fileupload : { required : "This field is required", extension: "Please upload valid file format. "},
        },
        submitHandler: function(insertForm) {
            
            var myForm = $("#careerform")[0];

            $.ajax({
                url: insertForm.action,
                type: insertForm.method,
                data: new FormData(myForm),
                mimeType: "multipart/form-data",
                contentType: false,
                cache: false,
                processData: false,
                success: function(data){
                      $("#careerform").trigger("reset");
                      $('#success').html('Thanks for contacting us.');
                       
                }
            });
},
    });
});


</script>