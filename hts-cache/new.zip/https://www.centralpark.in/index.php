    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#ffffff">
        <title>Central Park: Trusted Real Estate Developers</title>
    <meta name="description" content="Experience the pinnacle of luxury living at Central Park Gurgaon. Our meticulously crafted residential homes offer an unparalleled lifestyle, combining modern amenities with exquisite design. Discover why Central Park is the trusted choice for your luxury property investment in Gurgaon.">
    <meta name="keywords" content="Luxury homes in Gurgaon , Gurgaon luxury apartments , Central park gurgaon price , Central park residential , Luxury housing">
    <meta name="robots" content="noodp">
    <meta property="og:title" content="Central Park: Trusted Real Estate Developers">
    <meta property="og:site_name" content="Central Park - Luxury housing">
    <meta property="og:url" content="https://www.centralpark.in/">
    <meta property="og:description" content="Experience the pinnacle of luxury living at Central Park Gurgaon. Our meticulously crafted residential homes offer an unparalleled lifestyle, combining modern amenities with exquisite design. Discover why Central Park is the trusted choice for your luxury property investment in Gurgaon.">
    <meta property="og:image" content="https://www.centralpark.in/images/logo.png">
    <meta name="twitter:title" content="Central Park: Trusted Real Estate Developers">
    <meta name="twitter:description" content="Experience the pinnacle of luxury living at Central Park Gurgaon. Our meticulously crafted residential homes offer an unparalleled lifestyle, combining modern amenities with exquisite design. Discover why Central Park is the trusted choice for your luxury property investment in Gurgaon.">
    <meta name="twitter:image" content="https://www.centralpark.in/images/logo.png">
    
        <link rel="canonical" href="https://www.centralpark.in/">
        
    
    <!--Schema Tags-->
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Central Park",
  "url": "https://www.centralpark.in/",
  "logo": "https://www.centralpark.in/images/logo2.svg",
  "sameAs": [
    "https://www.facebook.com/CentralParkIn/",
    "https://twitter.com/CentralParkIn",
    "https://www.instagram.com/centralparkin/",
    "https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ",
    "https://www.linkedin.com/company/central-park-in/",
    "https://www.centralpark.in/"
  ]
}
</script>    <!--Stylecss-->
    
    <link rel="icon" type="image/x-icon" href="https://www.centralpark.in/images/faviv2.ico">
    <link rel="stylesheet" href="https://www.centralpark.in/css/style.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/responisve.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/animate.css"> 
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick-theme.css">  
    <link rel="stylesheet" href="https://www.centralpark.in/css/eocjs-newsticker.css">
   <link rel="stylesheet" href="https://www.centralpark.in/css/font-awesome.min.css">
   <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.0/css/all.min.css" integrity="sha512-9xKTRVabjVeZmc+GUW8GgSmcREDunMM+Dt/GrzchfN8tkwHizc5RP4Ok/MXFFy5rIjJjzhndFScTceq5e6GvVQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />-->
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/OPTIMA.woff" type="font/woff" crossorigin="anonymous">
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/fontawesome-webfont.woff2?v=4.7.0" type="font/woff2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />--><!-- Facebook Pixel Code -->

<script>


!function(f,b,e,v,n,t,s)



{if(f.fbq)return;n=f.fbq=function(){n.callMethod?



n.callMethod.apply(n,arguments):n.queue.push(arguments)};



if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';



n.queue=[];t=b.createElement(e);t.async=!0;



t.src=v;s=b.getElementsByTagName(e)[0];



s.parentNode.insertBefore(t,s)}(window,document,'script',



'https://connect.facebook.net/en_US/fbevents.js');



fbq('init', '394540540386962');



fbq('track', 'PageView');


</script>

<noscript>

<img height="1" width="1"

src="https://www.facebook.com/tr?id=394540540386962&ev=PageView

&noscript=1"/>

</noscript>

<!-- End Facebook Pixel Code -->

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K5WV3Q');</script>
<!-- End Google Tag Manager -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-60041058-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-60041058-1');
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16495080556"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-16495080556');
</script>

<script>
  gtag('config', 'AW-16495080556/znPoCOHsm6UZEOzou7k9', {
    'phone_conversion_number': '+91 7065777702'
  });
</script>

<!-- Taboola Pixel Code -->
<!--<script type='text/javascript'>
  window._tfa = window._tfa || [];
  window._tfa.push({notify: 'event', name: 'page_view', id: 1429034});
  !function (t, f, a, x) {
         if (!document.getElementById(x)) {
            t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f);
         }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/unip/1429034/tfa.js',
  'tb_tfa_script');
</script>-->
<!-- End of Taboola Pixel Code -->


</head>

<body>
    
    <style>
        
        header {
    background: #00000014;
}
    </style>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K5WV3Q"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!-- Event snippet for Website Traffic views conversion page -->


    <div class="jsOverlay"></div>
    <div class="mainwrap">
            <style>
            span.s__0999 {
    background: transparent!important;
    font-size: 42px;
    color: #9e8061;
}
      
      .mainwrap .hospitalitysection .hospiinner {
    width: 100%;
    float: left;
    padding: 63px 0;
}      
     body.black_bg .logo-white {
    display: block;
}
            .mainwrap header .navigation .left .logo img {
   
    top: 0px!important;
}  
            
            .banner-caption {
    margin: auto;
    padding: 146px 0 13px;
    text-align: center;
}
            
            .valley_prallax .h3 {
    margin-bottom: 34px;
}  
            .valley_prallax {
    padding-top: 148px;
}
</style>
        <header>  
            <div class="navigation">
                <div class="width90">
                    <div class="left">
                        <div class="logo d-flex">
                            <a href="https://www.centralpark.in/" class="line-cp">
                                <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="49" class="logo-white lazy" alt="Central Park Logo">-->
                                <!--<img src="https://www.centralpark.in/images/logo2.svg" width="227" height="49" class="logo-black lazy" alt="Central Park Logo">-->
                                <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="49" class="logo-white lazy" alt="Central Park Logo">
                            </a>
                                                        <img src="https://www.centralpark.in/images/20-Years-white.svg" width="34" height="62" class="years20 lazy" alt="Central Park - 20 Years of curating a privileged lifestyle">
                                                    </div>
                    </div>
                    <div class="right">
                        <div class="headernav">
                            <div class="navtoggle opennav">
                                <a href="javascript:void(0)" title="Open">
                                    <span></span>
                                    <span></span>
                                </a>
                            </div>
                            <div class="topsmnav">
                                <ul>
                                    <!--<li><a href="https://www.centralpark.in/pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                    <li><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></li>
                                    <!--<li><a href="javascript:void(0)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">-->
                                    <!--    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>-->
                                    <!--  </svg></a></li>-->
                                </ul>
                            </div>
                            <div class="mainnav">
                                <ul>
                                    <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                    <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                    <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                    <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                </ul>
                            </div>                            
                        </div>
                    </div>
                </div>
                <div class="windowheightnav">
                    <div class="navclose closenav">
                        <a href="javascript:void(0)" title="Close">
                            <span class="s__0999">x</span>  
                        </a>
                    </div>
                    <div class="windogrid">
                        <div class="lrsection">
                            <div class="parknavbar">
                                 <div class="width70">
                                     
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/residential.php">Residential</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/commercial.php">Commercial</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></strong>
                                    </div>
                                    
                                     <div class="innernavbar">
                                         <span>&nbsp;</span>
                                         <strong><a href="https://www.centralpark.in/about-us.php">About Us</a></strong>
                                         <ul>
                                             <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#team">LEADERSHIP</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                         </ul>
                                     </div>

                                     <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/group.php">Group</a></strong>
                                        <ul>
                                            <li><a href="https://www.centralpark.in/group.php#automotive">Automotive</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#infrastructure">Infrastructure</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#education">Education</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#hospitality">Hospitality</a></li>
                                        </ul> 
                                    </div>

                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/media.php">Media</a></strong>
                                         <ul>
                                            <li><a href="https://www.centralpark.in/media.php#tab1" onClick="loadmr('1');">News Coverage </a></li>
                                            <li><a href="https://www.centralpark.in/media.php#tab2" onClick="loadmr('2');">VIDEO GALLERY</a></li>
                                        </ul> 
                                    </div>
                                    
                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></strong>
                                    </div>
                                    
                                    <div class="d-none top-menu-headr">
                                        <ul class="small-menu_list">
                                            <!--<li><a href="pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                        </ul>
                                    </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        
        
      <div class="popup custom-popup" data-popup="popup-1">
    <div class="popup-inner">
        <h2>Enquire Now</h2>
        
        <div class="pd100  contact-wrapper">
       
                <div class="form">
                    <p id="success_1" style="color: green;font-size: 14px;"></p>
                    <p id="reCaptchaError_1" style="color:red;"></p>
                    <form action="enquireData.php" method="POST" id="enquire_now_form">
                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control let" placeholder="Name" name="enquire_now_name" id="enquire_now_name">
                        </div>
                        <div class="form-group w50 lt-50">
                           <input type="text" class="form-control" placeholder="Email"  name="enquire_now_email" id="enquire_now_email">
                        </div>

                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control" placeholder="Phone Number" name="enquire_now_phone" id="enquire_now_phone" maxlength="10" onkeypress="return isNumberKey(event,this)">
                        </div>
                        
                        <div class="form-group w50 lt-50">
                            <select class="form-control" name="enquire_now_project" id="enquire_now_project">
                              <option value="">Select Projects</option>
                              <option value="Aqua Front Tower&Central Park Flower Valley">Aqua Front Tower</option>
                              <option value="Central Park Flower Valley&Central Park Flower Valley">Central Park Flower Valley</option>
                              <option value="Cerise Floors&Central Park Flower Valley">Cerise Floors</option>
                              <option value="Clover Floors&Central Park Flower Valley">Clover Floors</option>
                              <option value="Flamingo Floors&Central Park Flower Valley">Flamingo Floors</option>
                              <option value="Fleur Villa&Central Park Flower Valley">Fleur Villa</option>
                              <option value="Mikasa&Central Park Flower Valley">Mikasa</option>
                              <option value="The Room - Flower Valley&Central Park Flower Valley">The Room - Flower Valley</option>
                              <option value="Beau Villas&Central Park Resorts">Beau Villas</option>
                              <option value="Belgravia Apartments&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Bellavista&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Central Park Resorts&Central Park Resorts">Central Park Resorts</option>
                              <option value="The Room&Central Park Resorts">The Room</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                           <textarea  class="form-control" placeholder="Message" name="enquire_now_msg" id="enquire_now_msg" rows="1"></textarea>
                        </div>
                        <input type="hidden" name="page_source" value="">

                      
                        
                        <button class="btn btn_submit btnSubmit"  type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72">
                                <defs>
                                    <style>
                                        .cls-1 {
                                            fill: none;
                                            stroke: #9e8061;
                                            stroke-miterlimit: 10;
                                        }
                                    </style>
                                </defs>
                                <g id="Layer_10" data-name="Layer 2">
                                    <g id="Layer_1-10" data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"></path></g>
                                </g>
                            </svg>
                            <span>Submit<b class="upcom"></b></span> 
                        </button>
                    </form>
                </div>
            </div>
            
        

        
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
    </div>
</div>  
<!--<div class="cookiesaccept">-->
<!--    <div class="container">-->
<!--        <div class="cookiesacept-mains">-->
<!--            <h2>This website use cookies to help you have a superior and admissible browsing experience on the website</h2>-->
            
<!--            <div class="thebuttonnsd">-->
<!--                <button class="acceptedds" id="setCookieBtn">Accept All</button>-->
<!--                <button>Reject All</button>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->


<div class="cookiesaccept" id="cookieNotice">
    <div class="container">
        <div class="cookiesacept-mains">
            <h2>This website uses cookies to help you have a superior and admissible browsing experience on the website.</h2>
            
            <div class="thebuttonnsd">
                <button class="acceptedds" id="setCookieBtn">Accept All</button>
                <button id="rejectCookiesBtn">Reject All</button>
            </div>
        </div>
    </div>
</div>

        <!--Banner section-->
        <div>
            <div class="bannervdwrap banht">
                <div class="videobg">
                    <!--<img class="dkact" src="images/homebanner/homebanner-new.jpg" alt="Immerse yourself in luxurious housing amidst nature's embrace at Central Park">-->
                     <!--<a class="tabactive" href="https://www.centralpark.in/the-orchard.php"><img src="images/homebanner/tab-homebanner-new.jpg" alt="Experience the splendor of luxury housing amidst nature's beauty at Central Park"></a>-->
                     <!--<a class="mobactive" href="https://www.centralpark.in/the-orchard.php"><img src="images/homebanner/mob-homebanner-new.jpg" alt="Indulge in the opulence of luxury housing surrounded by nature at Central Park"></a>-->
                    <div class="overlay_video"></div>
                    <video id="video" autoplay loop muted playsinline>
                        <source src="images/homebanner/homepage.mp4" type="video/mp4">
                        <source src="images/homebanner/homepage.ogv" type="video/ogv">
                        <source src="images/homebanner/homepage.webm" type="video/webm">
                    </video>                    
                </div>
                <!--<div class="bannertextwrap">-->
                <!--    <div class="width50">-->
                <!--        <div class="upertext wow animate__animated animate__fadeIn">-->
                <!--            <strong>ICONIC<br/><b>LIVING</b></strong>-->
                <!--            <span>SPACES THAT INSPIRE LIVES</span>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="leftrightnav">
                    <div class="width75">
                        <div class="leftnav">
                            <div class="innerleftnav">
                                <ul>
                                    <li class="wow animate__animated animate__fadeIn"><a href="https://www.centralpark.in/contact-us.php">Contact Us <span class="cont"></span></a></li>
                                    <li class="wow animate__animated animate__fadeIn"><a href="https://www.centralpark.in/selene.php">New Launch <span class="upcom"></span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mn_c_ln"></div>
                <div class="chatbox">
                    <div class="chat-menu">
            			<a href="tel:917065777702" ><img src="images/phone.svg" alt=""><span>Connect Via Call</span></a>
            			<a href="mailto:info@centralpark.in"><img src="images/email.svg" alt=""><span>Connect Via E-mail</span></a>
            		</div>
                    <a href="javascript:void(0)">
                        <img src="images/message.svg" width="20" alt="">
                    </a>
                </div>
            </div>
        </div>
        <!--Banner section-->

        <!--Hospitality-->
        <div class="relative">
            <div class="hospitalitysection">
                <div class="width90">
                    <div class="hospiinner">
                        <h1 class="wow animate__animated animate__fadeInUp" data-wow-delay="0.1s">WELCOME TO CENTRAL PARK </h1>
                        <h2 class="headingtag wow animate__animated animate__fadeInUp" data-wow-delay="0.3s">Homes Fused with <br class="hide">Hospitality</h2>

                        <div class="gridsection">
                            <div class="itemg">
                                <div class="btndiscover wow animate__animated animate__fadeInUp"  data-wow-delay="0.8s">
                                    <a href="https://www.centralpark.in/about-us.php">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72"><defs><style>.cls-1{fill:none;stroke:#9e8061;stroke-miterlimit:10;}</style></defs><g  data-name="Layer 2"><g data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"/></g></g></svg>                                        <span> Discover More <b class="upcom"></b></span>
                                    </a>
                                </div>
                            </div>
                            <div class="itemg">
                                <div class="hostextwrap wow animate__animated animate__fadeInUp" data-wow-delay="0.5s">
                                    <p>Focused on providing quality to everyday life, 'The Central Park Way' is a tireless endeavour that strives towards delivering an extraordinary customer experience. Our concept based luxury homes with in-house hospitality services make our residential properties the most sought after. After existing as a leader in real estate for years, the qualities imbibed in us are a testament of delivering luxury lifestyle experiences and care for those than place their trust in us. Now spanning across Gurugram, Delhi and Goa.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Our Projects-->
        <div class="project-wrapper">            
            <div class="projectssection section">
                <div id="slidetext" >Central Park</div>
                <div class="width90">
                    <div class="proinner">
                        <span class="wow animate__animated animate__fadeInUp" data-wow-delay="0.1s">Our Projects</span>
                        <h2 class="headingtag wow animate__animated animate__fadeInUp" data-wow-delay="0.3s">One for every<br class="hide">facet of life</h2>
                    </div>
                </div>
                
                
             


              <div class="gridanimated down">
                    <div class="innergridpro">
                        <div class="itemwrap" id="pro1">
                            <a href="https://www.centralpark.in/residential.php">
                                <div class="gridbackg">
                                    <!--<div class="square square-one" data-duration="1800" data-offset="400"></div>
                                    <div class="bottoms" data-duration="3000" data-offset="360"></div>-->
                                    <div class="resfixed"></div>
                                    <img class="res" src="images/progrigbg/1.jpg" alt="Explore Central Park's exquisite residential properties" title="Explore Central Park's exquisite residential properties">
                                    <strong  class="wow animate__animated animate__fadeInUp" data-wow-delay="0.1s">Residential</strong>
                                    
                                </div>
                            </a>
                        </div>
                        <div class="itemwrap" id="pro2">
                            <a href="https://www.centralpark.in/commercial.php">
                                <div class="gridbackg">
                                   <!-- <div class="square square-two" data-duration="1800" data-offset="300"></div>
                                    <div class="bottoms" data-duration="2800" data-offset="450"></div>-->
                                    <div class="comfixed"></div>
                                    <img class="com" src="images/progrigbg/2.jpg" alt="Discover commercial properties offered by Central Park" title="Discover commercial properties offered by Central Park">
                                    <strong  class="wow animate__animated animate__fadeInUp" data-wow-delay="0.3s">Commercial</strong>
                                </div>
                            </a>
                        </div>
                        <div class="itemwrap" id="pro3">
                            <a href="https://www.centralpark.in/hospitality.php">
                                <div class="gridbackg">
                                   <!--<div class="square square-one" data-duration="1800" data-offset="420"></div>
                                   <div class="bottoms" data-duration="3000" data-offset="360"></div>-->
                                    <div class="hosfixed"></div>
                                    <img class="hos" src="images/progrigbg/3.jpg" alt="Experience exceptional hospitality services provided by Central Park" title="Experience exceptional hospitality services provided by Central Park">
                                    <strong  class="wow animate__animated animate__fadeInUp" data-wow-delay="0.5s">Hospitality</strong>
                                </div>
                            </a>
                        </div>
                        <div class="itemwrap" id="pro4">
                            <a href="https://www.centralpark.in/listing.php?type=leasing">
                                <div class="gridbackg">
                                   <!-- <div class="square square-two" data-duration="1800" data-offset="300"></div>
                                    <div class="bottoms" data-duration="2800" data-offset="450"></div>-->
                                    <div class="leafixed"></div>
                                    <img  class="lea" src="images/progrigbg/4.jpg" alt="Explore the option of leasing properties from Central Park" title="Explore the option of leasing properties from Central Park">
                                    <strong  class="wow animate__animated animate__fadeInUp" data-wow-delay="0.7s">Leasing</strong>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>  
            </div>
        </div>
        
        <div class="clear"></div>
        
        <!--Latest News-->
        <div class="homesapce">
            <div class="newssection">
                <div class="width90">
                    <div class="latestninner">
                        <span class="wow animate__animated cog_js" data-wow-delay="0.2s">Latest News</span>

                        <div class="gridsection">
                            <div class="itemg">
                                <div class="newsheading">
                                    <h2 class="headingtag wow animate__animated cog_js" data-wow-delay="0.3s">There's<br class="hide"> plenty going<br class="hide"> on at <br class="hide"> Central Park</h2>

                                    <a href="media.php#tab1"  class="wow animate__animated cog_js" data-wow-delay="1s">
                                       <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72"><defs><style>.cls-1{fill:none;stroke:#9e8061;stroke-miterlimit:10;}</style></defs><g  data-name="Layer 2"><g data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"/></g></g></svg>                                       <span> Browse All News <b class="upcom"></b></span>
                                    </a>
                                </div>
                            </div>

                            <div class="itemg">
                                <div class="slide newsslider margtop wow animate__animated cog_js" data-wow-delay="0.7s">
                                    
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>18</strong>
                                                    <span>Oct 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Diwali night (Diwali carnival with Harshdeep Kaur)</strong>
                                                    <p>Experience an enchanting Diwali Night on 18th October at Central Park, featuring a mesmerizing live performance by Bollywood sensation Harshdeep Kaur.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>12</strong>
                                                    <span>Oct 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Dusshera (Ram Leela Utsav)</strong>
                                                    <p>Celebrate the grandeur of Dusshera (Ram Leela Utsav) on 12th October at Central Park and witness the triumph of good over evil with captivating performances and a majestic evening of festive celebration.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>11</strong>
                                                    <span>Oct 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Dandiya Night (Garba Raas)</strong>
                                                    <p>Step into an evening of elegance and rhythm at Dandiya Night (Garba Raas) on 11th October at Central Park. celebrate and enjoy an unforgettable night of music and dance.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>09</strong>
                                                    <span>Oct 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Durgostav - 9 Oct - 13 Oct</strong>
                                                    <p>Join us at Central Park for Durgostav from 9th to 13th October, a vibrant celebration of Durga Puja with traditional rituals, and festive joy</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>06</strong>
                                                    <span>Oct 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Meditation and sound healing</strong>
                                                    <p>Immerse yourself in tranquility at Meditation and Sound Healing on 6th October at Central Park. Rejuvenate your mind and soul with a serene session, blending calming meditation and therapeutic sound vibrations in a peaceful environment.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>25</strong>
                                                    <span>Mar 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Holi Festivities</strong>
                                                    <p>The echoes of laughter and splashes of color filled Central Park as residents embraced the festive spirit of Holi.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>13</strong>
                                                    <span>Mar 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Baisakhi Event</strong>
                                                    <p>Central Park embraced the rhythms of Baisakhi and celebrated the vibrant spirit of togetherness.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>10</strong>
                                                    <span>Mar 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Flower Show</strong>
                                                    <p>The floral spectacle held at Central Park Flower Valley and Central Park Resorts to calm your senses and your soul.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>09</strong>
                                                    <span>Mar 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>DBBR Event</strong>
                                                    <p>Central Park hosted a successful event in collaboration with DBBR Team, a event was a true celebration of community spirit.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>26</strong>
                                                    <span>Jan 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Republic Day Celebrations</strong>
                                                    <p>Central Park celebrated the vibrant diversity and unity of our nation.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="newsslidewrap">
                                            <div class="left">
                                                <div class="dategrid">
                                                    <strong>22</strong>
                                                    <span>Jan 2024</span>
                                                </div>
                                            </div>
                                            <div class="right">
                                                <div class="slidetextgrid">
                                                    <strong>Ram Mandir Pran Pratishtha</strong>
                                                    <p>Residents of Central Park come together to honor and embrace the divine spirit of Lord Ram.</p>
                                                </div>
                                            </div>
                                        </div>
                                                                    </div>                      
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


 <div class="clear"></div>
        
     <!--   <div class="aqi-index pad80 ">
            <div class="width90">
                <div class="d-flex">
                    <div class="aqi_head">
                        <h4 class="h4 wow animate__animated animate__fadeInUp" data-wow-delay="0.2s">AQI Index</h4>
                    </div>
                    <div class="aqi_data">
                        <div class="d-flex">
                            <div class="aqi_list">
                                <h6 class="wow animate__animated animate__fadeInUp" data-wow-delay="0.2s">central park</h6>
                                <p class="wow animate__animated animate__fadeInUp" data-wow-delay="0.2s">Good</p>
                            </div>
                            <div class="aqi_list">
                                <h6 class="wow animate__animated animate__fadeInUp" data-wow-delay="0.2s">OUTSide</h6>
                                <p class="wow animate__animated animate__fadeInUp" data-wow-delay="0.2s">Poor</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
        <!--Testimonial-->
        <div >
            <!--<div class="testimonialsection">-->
            <!--    <div class="width90">-->
            <!--        <div class="testinner">-->
            <!--            <span class="wow animate__animated animate__fadeInUp" data-wow-delay="0.2s">Testimonial</span>-->
            <!--            <h2 class="headingtag wow animate__animated animate__fadeInUp" data-wow-delay="0.4s">Hear about us from<br class="hide"> our customers</h2>-->
            <!--        </div>-->
            <!--        <div class="vediogrid">-->
            <!--            <div class="vdgrid">-->
            <!--                <div class="vditemgrid wow animate__animated cog_js" data-wow-delay="0.6s">-->
            <!--                    <div class="testimon mg_image">-->
            <!--                        <div class="bgbackplay">-->
            <!--                            <iframe id="change-image" src="https://www.youtube.com/embed/95atL7HM8Ic?si=LhWvXtnQQLpRntcr" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;" allowfullscreen style="border:0;"></iframe>-->
            <!--                        </div>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--                <div class="vditemgrid">-->
            <!--                    <div class="overlayout">-->
            <!--                        <div class="rigthtest">-->
            <!--                            <div class="innertesti wow animate__animated cog_js" data-wow-delay="0.8s">-->
            <!--                                <div class="scimgtest test1">-->
            <!--                                    <img src="images/video2.jpg" alt="Read customer testimonials for Central Park's exceptional services" title="Read customer testimonials for Central Park's exceptional services">-->
            <!--                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90.26 90.26"><g data-name="Layer 2"><g data-name="Layer 1"><circle class="cls-1" cx="45.13" cy="45.13" r="44.76"/><polygon class="cls-2" points="38.15 59.12 38.15 31.14 62.63 45.13 38.15 59.12"/></g></g></svg>-->
            <!--                                </div>-->
            <!--                            </div>-->
    
            <!--                            <div class="innertesti wow animate__animated cog_js" data-wow-delay="1s">-->
            <!--                                <div class="scimgtest test2">-->
            <!--                                    <img src="images/video1.jpg" alt="Discover customer testimonials for Central Park Flower Valley" title="Discover customer testimonials for Central Park Flower Valley">-->
            <!--                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90.26 90.26"><g data-name="Layer 2"><g data-name="Layer 1"><circle class="cls-1" cx="45.13" cy="45.13" r="44.76"/><polygon class="cls-2" points="38.15 59.12 38.15 31.14 62.63 45.13 38.15 59.12"/></g></g></svg>-->
            <!--                                </div>-->
            <!--                            </div>-->

            <!--                        </div>-->
            <!--                    </div>                            -->
            <!--                </div>-->
            <!--            </div>                        -->
            <!--        </div>-->

            <!--        <div class="hoverbtn">-->
            <!--            <a href="jjavascript:void(0)" class="width90 wow animate__animated animate__fadeInUp" data-wow-delay="1s">-->
            <!--                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72"><defs><style>.cls-1{fill:none;stroke:#9e8061;stroke-miterlimit:10;}</style></defs><g  data-name="Layer 2"><g data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"/></g></g></svg>-->
            <!--               <span> Watch All Videos <b class="upcom"></b></span>-->
            <!--            </a>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            
            
            
            
            
            
            
            
            
            <div class="testimonialsection">
    <div class="width90">
        <div class="testinner">
            <span class="wow animate__animated animate__fadeInUp" data-wow-delay="0.2s">Testimonial</span>
            <h2 class="headingtag wow animate__animated animate__fadeInUp" data-wow-delay="0.4s">Hear about us from<br class="hide"> our customers</h2>
        </div>
        <div class="vediogrid">
            <div class="vdgrid s__001144">
                <!-- Video Section -->
                
                 <div class="swiper mySwipertest">
    <div class="swiper-wrapper">
        <div class="swiper-slide">
            <a href="https://youtu.be/LdOreCcyKXU?si=3FE_PNz6LYjNkTLH" target="_blank">
          <div class="widt1144">
                <div class="vditemgrid wow animate__animated cog_js" data-wow-delay="0.6s">
                    <div class="testimon mg_image">
                        <div class="bgbackplay">
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/LdOreCcyKXU?si=8MNOPbMFeRoGTp4k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                </div>
          
          <!--<div class="theyoutubethumb">-->
          <!--    <div class="theyoutubeimages">-->
          <!--        <img src="images/thumbs1.jpg">-->
          <!--    </div>-->
          <!--    <div class="theyotubeicons">-->
          <!--        <i class="fa-brands fa-youtube"></i>-->
          <!--    </div>-->
          <!--</div>-->
                </a>
      </div>
      <div class="swiper-slide">
          <a href="https://youtu.be/_j5-ISR95cw?si=U4v9vsYxg2W2wrIe" target="_blank">
          <div class="widt1144">
                <div class="vditemgrid wow animate__animated cog_js" data-wow-delay="0.6s">
                    <div class="testimon mg_image">
                        <div class="bgbackplay">
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/_j5-ISR95cw?si=4vYyXNm40hTzkPYV" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                </div>
                </a>
      </div>
      <div class="swiper-slide">
          <a href="https://youtu.be/0-bHVX4MfCM?si=lQNO2zf8knGTSBM9" target="_blank">
          <div class="widt1144">
                <div class="vditemgrid wow animate__animated cog_js" data-wow-delay="0.6s">
                    <div class="testimon mg_image">
                        <div class="bgbackplay">
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/0-bHVX4MfCM?si=VRxd7Xki_XcBfVGy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                </div>
                </a>
      </div>
      <div class="swiper-slide">
          <a href="https://youtu.be/R_a3J5Cv5V8?si=ah2VzBqCJsQ1F42o" target="_blank">
         <div class="widt1144">
                <div class="vditemgrid wow animate__animated cog_js" data-wow-delay="0.6s">
                    <div class="testimon mg_image">
                        <div class="bgbackplay">
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/R_a3J5Cv5V8?si=V6FWhvkW7z4e9Z41" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                </div>
                </a>
      </div>
    
    </div>
    
  </div>
                
                 
                 
                <div class="thepaggissds">
                    <div class="swiper-pagination"></div>
                </div>
                
                
                <!-- Thumbnails Section -->
<!--
                <div class="vditemgrid">
                    <div class="overlayout">
                        <div class="rigthtest">
                            <div class="innertesti wow animate__animated cog_js" data-wow-delay="0.8s" onclick="playVideo('new-video-url-1')">
                                <div class="scimgtest test1">
                                    <img src="images/newthumbs2.jpg" alt="Read customer testimonials for Central Park's exceptional services" title="Read customer testimonials for Central Park's exceptional services">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90.26 90.26"><g data-name="Layer 2"><g data-name="Layer 1"><circle class="cls-1" cx="45.13" cy="45.13" r="44.76"/><polygon class="cls-2" points="38.15 59.12 38.15 31.14 62.63 45.13 38.15 59.12"/></g></g></svg>                                </div>
                            </div>
                            <div class="innertesti wow animate__animated cog_js" data-wow-delay="1s" onclick="playVideo('new-video-url-2')">
                                <div class="scimgtest test2">
                                    <img src="images/newthumbs3.jpg" alt="Discover customer testimonials for Central Park Flower Valley" title="Discover customer testimonials for Central Park Flower Valley">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90.26 90.26"><g data-name="Layer 2"><g data-name="Layer 1"><circle class="cls-1" cx="45.13" cy="45.13" r="44.76"/><polygon class="cls-2" points="38.15 59.12 38.15 31.14 62.63 45.13 38.15 59.12"/></g></g></svg>                                </div>
                            </div>
                        </div>
                    </div>                            
                </div>
-->
            </div>                        
        </div>

        <div class="hoverbtn">
            <a href="https://youtube.com/playlist?list=PLKAJEEr4jZBoKPFtIsa2rwXRetJE6hQ5Q&si=rnS-BWRbDkQqlzQB" class="width90 wow animate__animated animate__fadeInUp" data-wow-delay="1s">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72"><defs><style>.cls-1{fill:none;stroke:#9e8061;stroke-miterlimit:10;}</style></defs><g  data-name="Layer 2"><g data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"/></g></g></svg>                <span> Watch All Videos <b class="upcom"></b></span>
            </a>
        </div>
    </div>
</div>
            
            
              
            
            
          <style>
            @media screen and (min-width:320px) and (max-width:767px)
             {
            
            .vdgrid.s__001144 .widt1144 { 
    width: 100%;  
}
            }
            
            
            </style>
              
            
            
            
            
            
            
        </div>

          <style>
            @media screen and (min-width:320px) and (max-width:767px)
             {
            
            
            }
            
            .thepaggissds {
    padding-top: 50px;
}
            </style>
            
                
  <style>
.mainwrap footer .footerinner .footermedia {
    width: 90%;
    float: left;
    position: absolute;
    bottom: 7px;
}l
      .footnavgrid {
    padding-bottom: 38px;
}
img.thererlogos {
    width: 60px;
}
</style>

  <!--Footer-->
        <footer>
            <div class="width90">
                <div class="footerinner">
                     <div class="footerlogo">
                         <div class="footgrid">
                             <div class="footitem">
                                 <div class="flogo">
                                     <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="43"  alt="Central Park Logo">-->
                                     <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="43"  alt="Central Park Logo">
                                 </div>
                             </div>

                             <div class="footitem">
                                <div class="footext">
                                    <p>The Median, Central Park Resorts, Sector – 48, Gurugram, Haryana 122018

 <a class="button map_underline" href="javascript:void(0)" onclick="loadMap('2')" id="map" >View Location Map</a></p>
                                </div>
                            </div>

                            <div class="footitem" >
                                <div class="footext" style="display:none">
                                    <p>Head Office :  <a href="mailto:info@headoffice.com">info@headoffice.com</a></p>
                                    <p>Sales Office : <a href="mailto:info@salesoffice.com">info@salesoffice.com</a></p>
                                </div>
                            </div>

                            <div class="footitem">
                                <a href="https://www.centralpark.in/listing.php">
                                <div class="footprope">
                                    <div class="width90">
                                        <div class="propgrid">
                                            <div class="propitem">
                                                <div class="fproptext">
                                                    <strong>Select A Property</strong>
                                                </div>
                                            </div>
                                            <div class="propitem">
                                                <div class="fproptext">
                                                   <img src="https://www.centralpark.in/images/footerimg.svg" width="60" height="60"  alt="footer icon">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </div>                            
                         </div>
                     </div>

                    <div class="footernav">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Central Park</strong>
                                    <ul>
                                        <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                        <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                        <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                        <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                        <li><a href="https://www.centralpark.in/crystaltown.php">Facility Management</a></li>
                                        <!--<li><a href="https://www.centralpark.in/pdf/CompiledSMCR_CPFV.pdf" target="_blank">Environmental Clearance</a></li>-->
                                    </ul>
                                </div>
                            </div>
                          <div class="footnavitem">
                                 <div class="footernavi">
                                    <strong>About Us</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/about-us.php">Who We Are</a></li>
                                       <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                        <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                       <li><a href="https://www.centralpark.in/blog/">Blogs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>NRI Corner</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/nri-corner.php">Why Central Park</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#whyindia">Why India</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#faq">FAQ's</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Careers</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/careers.php">Join Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Quick Links</strong>
                                    <ul>
                                                                               <li><a href="https://www.centralpark.in/refund-policy.php">Refund Policy</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/privacy-policy.php">Privacy Policy</a></li>
                                                                              <li><a href="https://www.centralpark.in/terms-conditions.php">Terms & Conditions</a></li>
                                       
                                                                           </ul>
                                </div>
                            </div>
                            
<!--                          -->


                            
                            <!--<div class="footnavitem borderrightleft">-->
                            <!--    <div class="width90">-->
                            <!--        <div class="footernavi">-->
                            <!--            <strong style="line-height: 1.2;"> Download Our Newsletter</strong>-->
                            <!--            <p>To stay updated about the ongoing events in the Central Park community and unravel the best of your future, check out our newsletter, The Chronicle. </p>-->
                            <!--            <div class="infileds">-->
                                            
                            <!--                <form class="infileds" action="dataSubscribe.php" method="POST" id="subscribe_form">-->
                            <!--                <input type="text" class="form-email" placeholder="Enter Your Email" id="email_sub" name="email_sub" >-->
                            <!--                <input type="hidden" id="footerPage" value="subscribeForm">-->
                            <!--                <button class="btn btn_submit"  type="submit"><img src="https://www.centralpark.in/images/footer_icon.svg" width="40" height="8"  alt="footer icon"></button>-->
                            <!--                </form>-->
                            <!--            </div>                                      <p id="success2" style="color:green;font-size: 14px;"></p>  -->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
<div class="thereeranumber">
    <p><span>RERA NO.:</span>Mikasa Plot : RC/REP/HARERA/GGM/95 OF 2017/7(3)/32/2023/09, RC/REP/HARERA/GGM/395/127/2020/11, RC/REP/HARERA/GGM/562/294/2022/37 | Fleur Villas: RC/REP/HARERA/GGM/624/356/2022/99 | Aqua Front Towers & The Room: RC/REP/HARERA/GGM/150 OF 2017/7(3)/34/2023/11  | The Orchard: RC/REP/HARERA/GGM/672/404/2023/16 | Bignonia Tower: RC/REP/HARERA/GGM/826/558/2024/53 | Bellavista: RC/REP/HARERA/GGM/379/111/2019/73 | The Selene Tower: RC/REP/HARERA/GGM/964/696/2025/67 | <a href="https://haryanarera.gov.in/" target="_blank">Haryanarera.gov.in</a></p>
</div>
                    <div class="footermedia">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Follow Us</strong>
                                    <ul>
                                        <li><a rel="nofollow" href="https://www.facebook.com/CentralParkIn/" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.instagram.com/centralparkin/"  target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ"  target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                        <!--<li><a rel="nofollow" href="https://twitter.com/CentralParkIn"  target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
                                        <li><a rel="nofollow" href="https://www.linkedin.com/company/central-park-in/"  target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp; ttt</strong>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp;</strong>
                                    <p class="pd-lt40">&copy;Centralpark 2025. All Rights Reserved</p>
                                </div>
                            </div>
                            <input type="hidden" id="is_home" name="is_home" value="https://www.centralpark.in/">
                            <input type="hidden" id="c_page" name="c_page" value="index.php">
                        </div>
                    </div>
                </div>
            </div>
        </footer>

<!--
        <div class="copyrights">
            <div class="text-center">
                <span><a href="https://cogculture.agency" target="_blank"> <img src="https://www.centralpark.in/images/cclogo.svg" width="22" height="16" alt="cogdigital"></a></span>
            </div>
        </div>
-->
            
        <div id="modal-container-location">
          <div class="modal-background">
            <div class="modal bg-white cnt-modal"  id="ConnectusOpen">
                <a href="javascript:void(0)" class="closebutton" ><img src="https://www.centralpark.in/images/icon-close.svg" width="17" height="17" alt="Central Park Icon Close"></a>
                
                <div class="width90" >
                <iframe src=""  id="Connectus"  style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
          </div>
          </div>
          
        
    </div>
    
    <input type="hidden" value="index.php" id="is_home">
    
       
    <script src="https://www.centralpark.in/js/jquery.min.js"></script>    
    <script src="https://www.centralpark.in/js/wow.min.js"></script>
    <script src="https://www.centralpark.in/js/slick.js"></script>
    <script src="https://www.centralpark.in/js/eocjs-newsticker.js"></script>
    
    <script src="https://www.centralpark.in/js/gsap.js" defer ></script>
    <script src="https://www.centralpark.in/js/ScrollTrigger.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollMagic.js" defer></script>
    <script src="https://www.centralpark.in/js/animation.gsap.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollToPlugin.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@17.6.1/dist/lazyload.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/additional-methods.js"></script>
    <!--<script src='https://unpkg.com/axios/dist/axios.min.js'></script>-->
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.0.0-alpha.1/axios.min.js"></script>-->
    <script src="https://www.centralpark.in/js/validation.js"></script>
    <script src="https://www.centralpark.in/js/custom.js"></script>
  
    <script>
        $(document).ready(function(){
            $("#slidetext").eocjsNewsticker({
                speed: 20,
                timeout: 1,
                divider: '',
                type: 'static'
            });
            
            // $.ajax({
            // 		url:"https://www.centralpark.in/aqi.php",
            // 		method:"GET",
            // 		success:function(response){
            // 		    var res = jQuery.parseJSON(response)
            //                  $('#resort_aqi').html(res.aqi_1)
            //                  $('#sohna_road_aqi').html(res.aqi_2)
            // 		}
            // });

        });
        
        // (function test() {

        //     axios({
        //       "async": true,
        //       "crossDomain": true,
        //       "url": "https://production.oizom.com/v1/data/cur",
        //       "method": "GET",
        //       "headers": {
        //         "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwNzAsIm9yZ0lkIjoiQ1AyMDE5MDUwMSIsInVzZXJFbWFpbCI6ImNwMjAxOTA1MDFAb2l6b20uY29tIiwiaWF0IjoxNjU2NjY4OTY3LCJleHAiOjE2ODgyMDQ5NjcsImlzcyI6IkNWSm9HdUgwZWhRRzViZEhyMzg3Y0tPZ1Nra3BOcGRsIn0.8xkfajwKv7_-M1AvNi6sK9MDXn4jSngjPt0ahjGjDIM",
        //         "cache-control": "no-cache",
        //         "postman-token": "30042871-ce0e-2dd5-dcd8-5635ec6ec140"
        //       }
        //     }).then(function(response) {
        //                     $('#resort_aqi').html(response.data[0].aqi)
        //                     $('#sohna_road_aqi').html(response.data[1].aqi)
        //                 })

        // })();
    
    </script>   
   <script>
  gtag('event', 'conversion', {'send_to': 'AW-16495080556/Dv0oCKTs3aIZEOzou7k9'});
</script>

<script>
  window.addEventListener('load', function() {
    if(window.location.pathname==("/") && window.document.referrer.includes("thanks.php")){
      gtag('event', 'conversion', {'send_to': 'AW-16495080556/7JrQCKHs3aIZEOzou7k9'});
    }
  });
</script>

<script>
  (function(){
    document.addEventListener('click', function(e){
      if(e.target.closest('a[href^="tel:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/IHfTCKfs3aIZEOzou7k9'});
      }
      if(e.target.closest('a[href^="mailto:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/yPy_CKrs3aIZEOzou7k9'});
      }
    });
  })();
</script>
   
   <script>
    function loadMap(v){
      if(v=="1")
        var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3506.9840833843336!2d77.10016661436981!3d28.48002598247817!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf47ab06242fb836a!2sGLOBAL%20BUSINESS%20PARK!5e0!3m2!1sen!2sin!4v1622103095919!5m2!1sen!2sin";
          
      if(v=="2")
        //   var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3508.830867361511!2d77.03224111507788!3d28.424359882500486!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbd478862f690aeca!2sCentral+Park+The+Resort!5e0!3m2!1sen!2sin!4v1530170396691";
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2481.144333967807!2d77.03577665122448!3d28.423240585612685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1878dee37f57%3A0xa9ecdd7d72782cf6!2sCentral%20Park%C2%AE!5e0!3m2!1sen!2sin!4v1649670949376!5m2!1sen!2sin";
            
            
            if(v=="3")
    
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
            
              
      if(v=="5")
           var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
      
       if(v=="6")
           var loc ="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3511.281450826602!2d77.06318704995007!3d28.350339303463272!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d233202703f8f%3A0x6069d5f67eb02f07!2sThe%20Room!5e0!3m2!1sen!2sin!4v1626854192717!5m2!1sen!2sin";
           
        if(v=="4")
          var loc = "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14035.267568735091!2d77.0347599!3d28.4247815!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x57c9a489284d2d27!2sBella%20Vista!5e0!3m2!1sen!2sin!4v1646810366352!5m2!1sen!2sin";
      
      document.getElementById("Connectus").setAttribute('src', loc);
      $('.wellnes-open').css("transform", "translate(0px, 0%)")  
      }
      function closeBtn(a){
         $('#ConnectusOpen').css("transform", "translate(0px, 100%)")
         document.getElementById("Connectus").setAttribute('src','');
      }
      
</script>
 <script>
//     $(".thebuttonnsd button").click(function () {
//     $(".cookiesaccept").css("display", "none");
// });
// </script>
 <script>
// // Function to set a cookie with a 1-day expiration
// function setCookie(name, value, days) {
//     var date = new Date();
//     date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
//     var expires = "expires=" + date.toUTCString();
//     document.cookie = name + "=" + value + ";" + expires + ";path=/";
// }

// // Add event listener to button
// document.getElementById('setCookieBtn').addEventListener('click', function() {
//     setCookie('myCookie', 'cookieValue', 1); // Set cookie for 1 day
//     alert('Cookie set for 1 day!');
// });
// </script>

<script>
    // Function to set a cookie with a specified expiration in days
    function setCookie(name, value, days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
        var expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    // Function to get a specific cookie by name
    function getCookie(name) {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.indexOf(name + "=") == 0) {
                return cookie.substring(name.length + 1);
            }
        }
        return "";
    }

    // Function to hide the cookie notice
    function hideCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'none';
    }

    // Function to show the cookie notice
    function showCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'block';
    }

    // Add event listener for 'Accept All' button
    document.getElementById('setCookieBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'true', 1); // Set cookie for 1 day
        hideCookieNotice(); // Hide cookie notice after acceptance
    });

    // Add event listener for 'Reject All' button (optional behavior)
    document.getElementById('rejectCookiesBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'false', 1); // Set rejection cookie
        hideCookieNotice(); // Hide cookie notice after rejection
    });

    // Function to check if the cookie is already set
    function checkCookie() {
        var acceptedCookies = getCookie('acceptedCookies');
        if (acceptedCookies === 'true') {
            hideCookieNotice(); // If cookies were accepted, hide the notice
        } else {
            showCookieNotice(); // If no cookie or rejected, show the notice
        }
    }

    // Run the checkCookie function on page load
    window.onload = checkCookie;
    </script>
     <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script>
    var swiper = new Swiper(".mySwipertest", {
      slidesPerView: 3,
      spaceBetween: 30,
    //   loop:true,
      autoplay: {
        delay: 50500,
        disableOnInteraction: false,
      },
        breakpoints: {
              320: {
          slidesPerView: 1,
          spaceBetween: 20,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 40,
        },
        1024: {
          slidesPerView: 3,
          spaceBetween: 50,
        },
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });
  </script>
</body>
</html>
