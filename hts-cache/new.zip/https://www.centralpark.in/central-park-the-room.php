    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#ffffff">
        <title>Central Park The Room: Luxury Studio Living in Gurgaon</title>
    <meta name="description" content="Experience unparalleled studio living at Central Park The Room. Enjoy world-class amenities, a clubhouse, and prime location, perfect for expats and young professionals in Gurgaon!
">
    <meta name="keywords" content="">
    <meta name="robots" content="noodp">
    <meta property="og:title" content="Central Park The Room: Luxury Studio Living in Gurgaon">
    <meta property="og:site_name" content="Central Park - Luxury Housing">
    <meta property="og:url" content="https://www.centralpark.in/central-park-the-room.php">
    <meta property="og:description" content="Experience unparalleled studio living at Central Park The Room. Enjoy world-class amenities, a clubhouse, and prime location, perfect for expats and young professionals in Gurgaon!
">
    <meta property="og:image" content="https://www.centralpark.in/images/logo.png">
    <meta name="twitter:title" content="Central Park The Room: Luxury Studio Living in Gurgaon">
    <meta name="twitter:description" content="Experience unparalleled studio living at Central Park The Room. Enjoy world-class amenities, a clubhouse, and prime location, perfect for expats and young professionals in Gurgaon!
">
    <meta name="twitter:image" content="https://www.centralpark.in/images/logo.png">
    
        <link rel="canonical" href="https://www.centralpark.in/central-park-the-room.php">
        
    
    <!--Schema Tags-->
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Central Park",
  "url": "https://www.centralpark.in/",
  "logo": "https://www.centralpark.in/images/logo2.svg",
  "sameAs": [  
    "https://www.facebook.com/CentralParkIn/",    
    "https://twitter.com/CentralParkIn",
    "https://www.instagram.com/centralparkin/",
    "https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ",
    "https://www.linkedin.com/company/central-park-in/",
    "https://www.centralpark.in/"
  ]
}
</script>    <!--Stylecss-->
    
    <link rel="icon" type="image/x-icon" href="https://www.centralpark.in/images/faviv2.ico">
    <link rel="stylesheet" href="https://www.centralpark.in/css/style.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/responisve.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/animate.css"> 
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick.css">
    <link rel="stylesheet" href="https://www.centralpark.in/css/slick-theme.css">  
    <link rel="stylesheet" href="https://www.centralpark.in/css/eocjs-newsticker.css">
   <link rel="stylesheet" href="https://www.centralpark.in/css/font-awesome.min.css">
   <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.0/css/all.min.css" integrity="sha512-9xKTRVabjVeZmc+GUW8GgSmcREDunMM+Dt/GrzchfN8tkwHizc5RP4Ok/MXFFy5rIjJjzhndFScTceq5e6GvVQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />-->
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/OPTIMA.woff" type="font/woff" crossorigin="anonymous">
   <link rel="preload" as="font" href="https://www.centralpark.in/fonts/fontawesome-webfont.woff2?v=4.7.0" type="font/woff2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />--><!-- Facebook Pixel Code -->

<script>


!function(f,b,e,v,n,t,s)



{if(f.fbq)return;n=f.fbq=function(){n.callMethod?



n.callMethod.apply(n,arguments):n.queue.push(arguments)};



if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';



n.queue=[];t=b.createElement(e);t.async=!0;



t.src=v;s=b.getElementsByTagName(e)[0];



s.parentNode.insertBefore(t,s)}(window,document,'script',



'https://connect.facebook.net/en_US/fbevents.js');



fbq('init', '394540540386962');



fbq('track', 'PageView');


</script>

<noscript>

<img height="1" width="1"

src="https://www.facebook.com/tr?id=394540540386962&ev=PageView

&noscript=1"/>

</noscript>

<!-- End Facebook Pixel Code -->

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K5WV3Q');</script>
<!-- End Google Tag Manager -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-60041058-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-60041058-1');
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16495080556"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-16495080556');
</script>

<script>
  gtag('config', 'AW-16495080556/znPoCOHsm6UZEOzou7k9', {
    'phone_conversion_number': '+91 7065777702'
  });
</script>

<!-- Taboola Pixel Code -->
<!--<script type='text/javascript'>
  window._tfa = window._tfa || [];
  window._tfa.push({notify: 'event', name: 'page_view', id: 1429034});
  !function (t, f, a, x) {
         if (!document.getElementById(x)) {
            t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f);
         }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/unip/1429034/tfa.js',
  'tb_tfa_script');
</script>-->
<!-- End of Taboola Pixel Code -->


</head>

<body>
    
    <style>
        
        header {
    background: #00000014;
}
    </style>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K5WV3Q"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!-- Event snippet for Website Traffic views conversion page -->


    <div class="jsOverlay"></div>
    <div class="mainwrap">
            <style>
            span.s__0999 {
    background: transparent!important;
    font-size: 42px;
    color: #9e8061;
}
      
      .mainwrap .hospitalitysection .hospiinner {
    width: 100%;
    float: left;
    padding: 63px 0;
}      
     body.black_bg .logo-white {
    display: block;
}
            .mainwrap header .navigation .left .logo img {
   
    top: 0px!important;
}  
            
            .banner-caption {
    margin: auto;
    padding: 146px 0 13px;
    text-align: center;
}
            
            .valley_prallax .h3 {
    margin-bottom: 34px;
}  
            .valley_prallax {
    padding-top: 148px;
}
</style>
        <header>  
            <div class="navigation">
                <div class="width90">
                    <div class="left">
                        <div class="logo d-flex">
                            <a href="https://www.centralpark.in/" class="">
                                <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="49" class="logo-white lazy" alt="Central Park Logo">-->
                                <!--<img src="https://www.centralpark.in/images/logo2.svg" width="227" height="49" class="logo-black lazy" alt="Central Park Logo">-->
                                <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="49" class="logo-white lazy" alt="Central Park Logo">
                            </a>
                                                        <img src="https://www.centralpark.in/images/20-Years.svg" width="34" height="62" class="years20 lazy" alt="Central Park - 20 Years of curating a privileged lifestyle">
                                                    </div>
                    </div>
                    <div class="right">
                        <div class="headernav">
                            <div class="navtoggle opennav">
                                <a href="javascript:void(0)" title="Open">
                                    <span></span>
                                    <span></span>
                                </a>
                            </div>
                            <div class="topsmnav">
                                <ul>
                                    <!--<li><a href="https://www.centralpark.in/pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                    <li><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></li>
                                    <!--<li><a href="javascript:void(0)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">-->
                                    <!--    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>-->
                                    <!--  </svg></a></li>-->
                                </ul>
                            </div>
                            <div class="mainnav">
                                <ul>
                                    <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                    <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                    <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                    <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                </ul>
                            </div>                            
                        </div>
                    </div>
                </div>
                <div class="windowheightnav">
                    <div class="navclose closenav">
                        <a href="javascript:void(0)" title="Close">
                            <span class="s__0999">x</span>  
                        </a>
                    </div>
                    <div class="windogrid">
                        <div class="lrsection">
                            <div class="parknavbar">
                                 <div class="width70">
                                     
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/residential.php">Residential</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/commercial.php">Commercial</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></strong>
                                    </div>
                                    <div class="innernavbar d-none">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></strong>
                                    </div>
                                    
                                     <div class="innernavbar">
                                         <span>&nbsp;</span>
                                         <strong><a href="https://www.centralpark.in/about-us.php">About Us</a></strong>
                                         <ul>
                                             <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#team">LEADERSHIP</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                             <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                         </ul>
                                     </div>

                                     <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/group.php">Group</a></strong>
                                        <ul>
                                            <li><a href="https://www.centralpark.in/group.php#automotive">Automotive</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#infrastructure">Infrastructure</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#education">Education</a></li>
                                            <li><a href="https://www.centralpark.in/group.php#hospitality">Hospitality</a></li>
                                        </ul> 
                                    </div>

                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/media.php">Media</a></strong>
                                         <ul>
                                            <li><a href="https://www.centralpark.in/media.php#tab1" onClick="loadmr('1');">News Coverage </a></li>
                                            <li><a href="https://www.centralpark.in/media.php#tab2" onClick="loadmr('2');">VIDEO GALLERY</a></li>
                                        </ul> 
                                    </div>
                                    
                                    <div class="innernavbar">
                                        <span>&nbsp;</span>
                                        <strong><a href="https://www.centralpark.in/contact-us.php">Contact Us</a></strong>
                                    </div>
                                    
                                    <div class="d-none top-menu-headr">
                                        <ul class="small-menu_list">
                                            <!--<li><a href="pay-online.php">Book Online</a></li>-->
                                    <!--<li><a href="https://www.centralpark.in/customer-portal.php" target="_blank">Customer Login</a></li>-->
                                    <li><a href="https://www.centralpark.in/foundation.php">CSR</a></li>
                                        </ul>
                                    </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        
        
      <div class="popup custom-popup" data-popup="popup-1">
    <div class="popup-inner">
        <h2>Enquire Now</h2>
        
        <div class="pd100  contact-wrapper">
       
                <div class="form">
                    <p id="success_1" style="color: green;font-size: 14px;"></p>
                    <p id="reCaptchaError_1" style="color:red;"></p>
                    <form action="enquireData.php" method="POST" id="enquire_now_form">
                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control let" placeholder="Name" name="enquire_now_name" id="enquire_now_name">
                        </div>
                        <div class="form-group w50 lt-50">
                           <input type="text" class="form-control" placeholder="Email"  name="enquire_now_email" id="enquire_now_email">
                        </div>

                        <div class="form-group w50 rt-50">
                           <input type="text" class="form-control" placeholder="Phone Number" name="enquire_now_phone" id="enquire_now_phone" maxlength="10" onkeypress="return isNumberKey(event,this)">
                        </div>
                        
                        <div class="form-group w50 lt-50">
                            <select class="form-control" name="enquire_now_project" id="enquire_now_project">
                              <option value="">Select Projects</option>
                              <option value="Aqua Front Tower&Central Park Flower Valley">Aqua Front Tower</option>
                              <option value="Central Park Flower Valley&Central Park Flower Valley">Central Park Flower Valley</option>
                              <option value="Cerise Floors&Central Park Flower Valley">Cerise Floors</option>
                              <option value="Clover Floors&Central Park Flower Valley">Clover Floors</option>
                              <option value="Flamingo Floors&Central Park Flower Valley">Flamingo Floors</option>
                              <option value="Fleur Villa&Central Park Flower Valley">Fleur Villa</option>
                              <option value="Mikasa&Central Park Flower Valley">Mikasa</option>
                              <option value="The Room - Flower Valley&Central Park Flower Valley">The Room - Flower Valley</option>
                              <option value="Beau Villas&Central Park Resorts">Beau Villas</option>
                              <option value="Belgravia Apartments&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Bellavista&Central Park Resorts">Belgravia Apartments</option>
                              <option value="Central Park Resorts&Central Park Resorts">Central Park Resorts</option>
                              <option value="The Room&Central Park Resorts">The Room</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                           <textarea  class="form-control" placeholder="Message" name="enquire_now_msg" id="enquire_now_msg" rows="1"></textarea>
                        </div>
                        <input type="hidden" name="page_source" value="">

                      
                        
                        <button class="btn btn_submit btnSubmit"  type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72">
                                <defs>
                                    <style>
                                        .cls-1 {
                                            fill: none;
                                            stroke: #9e8061;
                                            stroke-miterlimit: 10;
                                        }
                                    </style>
                                </defs>
                                <g id="Layer_10" data-name="Layer 2">
                                    <g id="Layer_1-10" data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"></path></g>
                                </g>
                            </svg>
                            <span>Submit<b class="upcom"></b></span> 
                        </button>
                    </form>
                </div>
            </div>
            
        

        
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
    </div>
</div>  

<div class="valley_prallax grey padd80" id="valley_prallax">
    <div class="width90">
        <div class="text-center">
            <span class="span wow animate__animated cog_js">WELCOME TO</span>
            <h1 class="h3 wow animate__animated cog_js">Central Park The Room
</h1>
        </div>
        <div class="breadcrumbslist wow animate__animated cog_js">
                <ul>
                    <li><a href="https://www.centralpark.in/">Home</a></li>
                    <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                    <li>Central Park The Room</li>
                </ul>
            </div>
        <div class="quadPicture">
            <div class="qPic w40 wow animate__animated animate__fadeInUp">
                <img class="full_width w-100" alt="Central Park The Room1" src="images/room1.jpg"  />
            </div>
            <div class="qPic w53 left wow animate__animated animate__fadeInUp">
                <img class="full_width w-100" alt="Central Park The Room2" src="images/room2.jpg" />
            </div>
            <div class="qPic w53 plus wow animate__animated animate__fadeInUp">
                <img class="full_width w-100" alt="Central Park The Room3" src="images/room3.jpg" />
            </div>
            <div class="qPic w40 left minus wow animate__animated animate__fadeInUp">
                <img class="full_width w-100" alt="Central Park The Room4" src="images/room4.jpg" />
            </div>
            <div class="apLogo show  wow animate__animated animate__fadeIn">
                <img src="images/THE-ROOMnewsize2.png" alt="Central Park The Room Logo" style="width:200px" />
            </div>

            <!--<div class="apOverlay">-->
            <!--    <div class="a show wow animate__animated animate__fadeInUp" data-wow-delay="0.4s">T</div>-->
            <!--    <div class="p show wow animate__animated animate__fadeInUp" data-wow-delay="0.6s">R</div>-->
            <!--</div>-->
        </div>
    </div>
</div>

<div class="padd80 logo_bg luxurious-wrap">
    <div class="width90">
        <span class="span wow animate__animated cog_js">OVERVIEW</span>
        <h2 class="h3 wow animate__animated cog_js">Experience international 
studio living at the room</h2>
        <p class="wow animate__animated cog_js">
            The Room brought a new point of view to the concept of studio residences. These residences offer everything you have been looking for in a 5-star living space: World Class Amenities complemented with best in class services. With its own clubhouse and a pool facing resturant,The Room has been a coveted residence for multinational executives and expats and helped the owners get the best rentals among any other residences. </p>
            
            <p class="wow animate__animated cog_js mt-o">Little wonder, that young corporate citizens, the expatriate community, and even couples find The Room as the perfect confluence of their needs. It is a popular choice among the Gen Y who finds it extremely convenient and well suited for their requirements.

</p>
    </div>
</div>


<!--<div class="padd80 valley-anemities mb-pad valley-dk">
    <div class="width90">
        <div class="horizontal-scroll-section">
                        <div class="scene">
                          <div class="horizontal-scroll-section__content-wrapper wrapper">
                              
                              
                        <div class="horizontal-scroll-section__content-section first-horizontal">
                             <div class="anemities-box">
                                 <span class="span  wow animate__animated cog_js">Exquisite Amenities</span>
                                 <h3 class="h3 wow animate__animated cog_js">A valley of wellness</h3>
                            </div>
                            </div>
                            
                            
                            <div class="horizontal-scroll-section__content-section">
                             <div class="anemities-box">
                                <div class="oveflow"><img src="images/Aroma Baths.jpg" class="w-100" /></div>
                                <h4>Aroma Baths</h4>
                            </div>
                            </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Foot Spa.jpg" class="w-100" /></div>
                        <h4>Footspa</h4>
                    </div>
                    </div>
                    
                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Naturopathy.jpg" class="w-100" /></div>
                        <h4>Naturopathy</h4>
                    </div>
                    </div>
                    
                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Head Massage.jpg" class="w-100" /></div>
                        <h4>Head Massage</h4>
                    </div>
                    </div>
                    
                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Reflexology.jpg" class="w-100" /></div>
                        <h4>Reflexology</h4>
                    </div>
                    </div>
                    
                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Body Massage.jpg" class="w-100" /></div>
                        <h4>Body Massage</h4>
                    </div>
                    </div>
                    
                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Steam.jpg" class="w-100" /></div>
                        <h4>Steam</h4>
                    </div>
                    </div>
                    
                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Sauna.jpg" class="w-100" /></div>
                        <h4>Sauna</h4>
                    </div>
                    </div>
                    
                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Jacuzzi.jpg" class="w-100" /></div>
                        <h4>Jacuzzi</h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Sun Bath.jpg" class="w-100" /></div>
                        <h4>Sun Bath</h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Herbal Parks.jpg" class="w-100" /></div>
                        <h4>Herbal Parks</h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Twin Fountains.jpg" class="w-100" /></div>
                        <h4>Twin Fountains</h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Nature Walks.jpg" class="w-100" /></div>
                        <h4>Nature Walks </h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Flora Fountain.jpg" class="w-100" /></div>
                        <h4>Flora Fountain</h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Detoxification Diet Sessions.jpg" class="w-100" /></div>
                        <h4>Detoxification Diet Sessions</h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Salad Bar.jpg" class="w-100" /></div>
                        <h4> Salad bar</h4>
                    </div>
                    </div>

                   <div class="horizontal-scroll-section__content-section">
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Organic Cafe.jpg" class="w-100" /></div>
                        <h4>Organic Cafe</h4>
                    </div>
                    </div>
                    
                            
                            
                            
                            
                          </div>
                        </div>
                    </div>
    </div>
</div>-->



<div class="padd80  valley-anemities">
     <div class="width90">
        <span class="span  wow animate__animated cog_js">Exquisite Amenities</span>
        <h2 class="h3 wow animate__animated cog_js">A valley of wellness</h2>
        
        <div class="innergridpro mb-slider artistic_label">
            
                             <div class="anemities-box">
                                <div class="oveflow"><img src="images/Aroma-Baths.jpg" class="w-100" alt="Central Park The Room Aroma Baths" /><span>Artistic Image</span></div>
                                <h5 class="h4">Aroma Baths</h5>
                            </div>                            

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Foot-Spa.jpg" class="w-100" alt="Central Park The Room Footspa" /><span>Artistic Image</span></div>
                        <h5 class="h4">Footspa</h5>
                    </div>                   
                    
                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Naturopathy.jpg" class="w-100" alt="Central Park The Room Naturopathy"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Naturopathy</h5>
                    </div>                   
                    
                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Head-Massage.jpg" class="w-100" alt="Central Park The Room Head Massage"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Head Massage</h5>
                    </div>                   
                    
                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Reflexology.jpg" class="w-100" alt="Central Park The Room Reflexology"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Reflexology</h5>
                    </div>                   
                    
                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Body-Massage.jpg" class="w-100" alt="Central Park The Room Body Massage"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Body Massage</h5>
                    </div>                   
                    
                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Steam.jpg" class="w-100" alt="Central Park The Room Steam"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Steam</h5>
                    </div>                   
                    
                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Sauna.jpg" class="w-100" alt="Central Park The Room Sauna"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Sauna</h5>
                    </div>                   
                    
                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Jacuzzi.jpg" class="w-100" alt="Central Park The Room Jacuzzi"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Jacuzzi</h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Sun-Bath.jpg" class="w-100" alt="Central Park The Room Sun Bath"  /><span>Artistic Image</span></div>
                       <h5 class="h4">Sun Bath</h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Herbal-Parks.jpg" class="w-100" alt="Central Park The Room Herbal Parks"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Herbal Parks</h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Twin-Fountains.jpg" class="w-100" alt="Central Park The Room Twin Fountains"  /><span>Shot On Location</span></div>
                        <h5 class="h4">Twin Fountains</h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Nature-Walks.jpg" class="w-100" alt="Central Park The Room Nature Walks"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Nature Walks </h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Flora-Fountain.jpg" class="w-100" alt="Central Park The Room Flora Fountain"  /><span>Shot On Location</span></div>
                        <h5 class="h4">Flora Fountain</h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Detoxification-Diet-Sessions.jpg"  alt="Central Park The Room Detoxification Diet Sessions" class="w-100" /><span>Artistic Image</span></div>
                        <h5 class="h4">Detoxification Diet Sessions</h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Salad-Bar.jpg" class="w-100" alt="Central Park The Room Salad bar"  /><span>Artistic Image</span></div>
                        <h5 class="h4"> Salad bar</h5>
                    </div>                   

                   
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Organic-Cafe.jpg" class="w-100" alt="Central Park The Room Organic Cafe"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Organic Cafe</h5>
                    </div>   
                    
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Basketball-Court.jpg" class="w-100" alt="Central Park The Room Basketball Court"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Basketball Court</h5>
                    </div> 
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Cricket-Practice-Nets.jpg" class="w-100" alt="Central Park The Room Cricket Practice Nets"   /><span>Artistic Image</span></div>
                        <h5 class="h4">Cricket Practice Nets</h5>
                    </div> 
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Golf-Putting-Chipping-Greens.jpg" class="w-100" alt="Central Park The Room Golf Putting & Chipping Greens"  /><span>Shot On Location</span></div>
                        <h5 class="h4">Golf Putting & Chipping Greens</h5>
                    </div> 
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/indoor-badminton.jpg" class="w-100" alt="Central Park The Room Indoor Badminton"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Indoor Badminton</h5>
                    </div> 
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/lawn-tennis.jpg" class="w-100" alt="Central Park The Room Lawn Tennis"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Lawn Tennis</h5>
                    </div> 
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/mini-football-zone.jpg" class="w-100" alt="Central Park The Room Mini-Football Zone"  /><span>Artistic Image</span></div>
                        <h5 class="h4">Mini-Football Zone</h5>
                    </div> 
                    <div class="anemities-box">
                        <div class="oveflow"><img src="images/Volleyball.jpg" class="w-100" alt="Central Park The Room Volleyball"  /><span>Artistic Image</span></div>
                        <h6 class="h4">Volleyball</h6>
                    </div> 
        </div>
        
     </div>
</div>



<div class="video mb-video">
    <div class="width90">
        <!--<div class="overlay_video"></div>-->
       <video id="video" autoplay loop muted playsinline>
            <source src="images/homebanner/homepage.mp4" type="video/mp4">
            <source src="images/homebanner/homepage.ogv" type="video/ogv">
            <source src="images/homebanner/homepage.webm" type="video/webm">
        </video>          
        </div>
</div>


<div class="aqi">
    <div class="width90">
          <div class="flex">
              <div class="aqi-name">
                  <h2 class="wow animate__animated cog_js">AIR Quality Index</h2>
                  <span class="wow animate__animated cog_js">Based on PM 2.5 and PM 10</span>
              </div>
              <div class="aqi-number">
                  <div class="flex">
                        <div class="aqi-list">
                            <span class="wow animate__animated cog_js" id="resort_aqi">17</span>
                            <p class="wow animate__animated cog_js">CENTRAL PARK RESORTS</p>
                        </div>
                        <div class="aqi-list active">
                            <span class="wow animate__animated cog_js" id="sohna_road_aqi">42</span>
                            <p class="wow animate__animated cog_js">SOHNA ROAD</p>
                        </div>
                  </div>
              </div>
          </div>     
    </div>
</div>




<div class="padd80 about-bellavista location flower-valley">
    <div class="width90">
        <span class="span wow animate__animated cog_js">LOCATION ADVANTAGE</span>
        <h2 class="h3 wow animate__animated cog_js">Where the world meets you</h2>

        <div class="row">
            <div class="col-md-4 relative">
                 <a href="javascript:void(0)" class="btn wow animate__animated cog_js" onclick="loadViewMap(3);">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72">
                        <defs>
                            <style>
                                .cls-1 {
                                    fill: none;
                                    stroke: #9e8061;
                                    stroke-miterlimit: 10;
                                }
                            </style>
                        </defs>
                        <g id="Layer_2" data-name="Layer 2">
                            <g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"></path></g>
                        </g>
                    </svg>
                    <span>View Location On Map <b class="upcom"></b></span>
                </a>
            </div>

            <div class="col-md-7">
                <div class="aboutTabDtls flower-valley-list">
                    <ul>
                        <li class="wow animate__animated cog_js">
                            <p> Located in sector 48, 25 minute drive from IGI airport</p>
                        </li>

                        <li class="wow animate__animated cog_js">
                            <p> Mere 12 minutes from Golf Course extension road</p>
                        </li>

                        <li class="wow animate__animated cog_js">
                            <p> 50 multinational companies located in the radius of 10KM</p>
                        </li>
                    </ul>
                    <ul>
                        <li class="wow animate__animated cog_js">
                            <p> Minutes away from IT and ITES SEZ</p>
                        </li>

                        <li class="wow animate__animated cog_js">
                            <p> In close proximity to well established schools (GD Goenka, DPS)</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="pd100  contact-wrapper">
    <div class="width90">
        <div class="row">
            <div class="col-md-6">
                <div class="add">
                <div class="title">
                <h2 class="wow animate__ animate__fadeInUp">Get in touch</h2>
              </div>
              
                                                        <p>10:00 AM to 07:00 PM<br> 
              <a href="tel:7065777702">+91 7065777702</a><br>
              <a href="mailto:marketing@centralpark.in">marketing@centralpark.in</a></p>
               <a href="pay-online.php" class="btns-line none">Book Online</a>
</div>
            </div>
            <div class="col-md-6">
                <div class="form wow animate__ animate__fadeInUp">
                    <p id="success" style="color: green;font-size: 14px;"></p>
                    <p id="reCaptchaError" style="color:red;"></p>
                    <form action="insertData.php" method="POST" id="customer_form">
                        <input type="text" class="data_pot ignore" autocomplete="off" type="text" id="data_field" name="data_field">
                        <div class="form-group">
                           <input type="text" class="form-control let" placeholder="Name" name="name" id="name">
                        </div>
                        <div class="form-group">
                           <input type="text" class="form-control" placeholder="Email"  name="email" id="email">
                        </div>
                        
                        
                        <div class="form-group">
                           <input type="text" class="form-control" placeholder="Phone Number" name="phone_number" id="phone_number" maxlength="10" onkeypress="return isNumberKey(event,this)">
                        </div>
                        
                        
                        <div class="form-group">
                           <textarea class="form-control" placeholder="Message" name="msg" id="msg" rows="1"></textarea>
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="enquire_now_project" id="enquire_now_project">
                              <option value="">Select Projects</option>
                              <option value="a0p5g000002rGq6AAE&The Orchard">The Orchard</option>
                              <option value="a0p5g000002rDcSAAU&Aqua Front Tower">Aqua Front Tower</option>
                              <option value="a0p5g000002rDPGAA2&Central Park Flower Valley">Central Park Flower Valley</option>
                              <option value="a0p5g000002rDP0AAM&Cerise Floors">Cerise Floors</option>
                              <option value="a0p5g000002rDPIAA2&Clover Floors">Clover Floors</option>
                              <option value="a0p5g000002rDPFAA2&Flamingo Floors">Flamingo Floors</option>
                              <option value="a0p5g000002rDPJAA2&Fleur Villa">Fleur Villa</option>
                              <option value="a0p5g000002rDOvAAM&Mikasa">Mikasa</option>
                              <option value="a0p5g000002rDPNAA2&The Room - Flower Valley">The Room - Flower Valley</option>
                              <option value="a0p5g000002rDPPAA2&Beau Villas">Beau Villas</option>
                              <option value="a0p5g000002rDPOAA2&Belgravia Apartments">Belgravia Apartments</option>
                              <option value="a0p5g000002rDOqAAM&Bellavista">Bellavista</option>
                              <option value="a0p5g000002rDPKAA2&Central Park Resorts">Central Park Resorts</option>
                              <option value="a0p5g000002rDPNAA2&The Room">The Room</option>
                            </select>
                        </div>
                        <!--<input type="hidden" name="page_source" value="">-->
                        
                        <input type="hidden" name="page_source" value="Project Page">
                        <div class="form-group">
                           <div class="s-input s-input--rounded">
                                <input type="checkbox" id="filter-rated6" name="customCheckbox" value="yes" >
                                <label for="filter-rated6">
                                  <i class="aria-hidden"></i>
                                    By submitting this form, we understand that you accept our privacy and data protection policy
                                </label>
                                <label for="customCheckbox" generated="true" class="error"></label>
                              </div>
                        </div>   
                        <div class="col-md-12">
                        <div class="form-group">
                           <div class="g-recaptcha" data-sitekey="6Lfvk84qAAAAAPBMy2VC7zCak5R8zmlBfn-YuLfq"></div>
                           <input type="hidden" class="hiddenRecaptcha1 required" name="hiddenRecaptcha1" id="hiddenRecaptcha1">
                           <label for="hiddenRecaptcha1" generated="true" class="error"></label>
                        </div>
                        </div>
                                   
                        
                        <button class="btn btn_submit"  type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46.84 53.72">
                                <defs>
                                    <style>
                                        .cls-1 {
                                            fill: none;
                                            stroke: #9e8061;
                                            stroke-miterlimit: 10;
                                        }
                                    </style>
                                </defs>
                                <g data-name="Layer 2">
                                    <g  data-name="Layer 1"><path class="cls-1" d="M46.47,44.49a26.36,26.36,0,1,1,0-35.26"></path></g>
                                </g>
                            </svg>
                            <span>Submit<b class="upcom"></b></span> 
                        </button>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</div>
 <script src="https://www.google.com/recaptcha/api.js"></script><div id="modal-container" class="wellnes-open">
    <div class="implent-box">
        <div class="c-team-popin__bar top_w"></div>
        <div class="c-team-popin__bar top_r"></div> 
        <div class="c-team-popin__bar top_b"></div> 
        <div class="c-team-popin__bar top_l"></div>
    </div>
  <div class="modal-background">
    <div class="modal bg-white cnt-modal"  id="ConnectusOpen">
        <a href="javascript:void(0)" class="closebutton" ><img  alt="close" src="images/icon-close.svg" /></a>
        
        <div class="width90" >
        <iframe src=""  id="Connectus" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </div>
  </div>
  </div>      
  <style>
.mainwrap footer .footerinner .footermedia {
    width: 90%;
    float: left;
    position: absolute;
    bottom: 7px;
}l
      .footnavgrid {
    padding-bottom: 38px;
}
img.thererlogos {
    width: 60px;
}
</style>

  <!--Footer-->
        <footer>
            <div class="width90">
                <div class="footerinner">
                     <div class="footerlogo">
                         <div class="footgrid">
                             <div class="footitem">
                                 <div class="flogo">
                                     <!--<img src="https://www.centralpark.in/images/logo.svg" width="227" height="43"  alt="Central Park Logo">-->
                                     <img src="https://www.centralpark.in/images/centralparklogo.png" width="50" height="43"  alt="Central Park Logo">
                                 </div>
                             </div>

                             <div class="footitem">
                                <div class="footext">
                                    <p>The Median, Central Park Resorts, Sector – 48, Gurugram, Haryana 122018

 <a class="button map_underline" href="javascript:void(0)" onclick="loadMap('2')" id="map" >View Location Map</a></p>
                                </div>
                            </div>

                            <div class="footitem" >
                                <div class="footext" style="display:none">
                                    <p>Head Office :  <a href="mailto:info@headoffice.com">info@headoffice.com</a></p>
                                    <p>Sales Office : <a href="mailto:info@salesoffice.com">info@salesoffice.com</a></p>
                                </div>
                            </div>

                            <div class="footitem">
                                <a href="https://www.centralpark.in/listing.php">
                                <div class="footprope">
                                    <div class="width90">
                                        <div class="propgrid">
                                            <div class="propitem">
                                                <div class="fproptext">
                                                    <strong>Select A Property</strong>
                                                </div>
                                            </div>
                                            <div class="propitem">
                                                <div class="fproptext">
                                                   <img src="https://www.centralpark.in/images/footerimg.svg" width="60" height="60"  alt="footer icon">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </div>                            
                         </div>
                     </div>

                    <div class="footernav">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Central Park</strong>
                                    <ul>
                                        <li><a href="https://www.centralpark.in/residential.php">Residential</a></li>
                                        <li><a href="https://www.centralpark.in/commercial.php">Commercial</a></li>
                                        <li><a href="https://www.centralpark.in/hospitality.php">Hospitality</a></li>
                                        <li><a href="https://www.centralpark.in/listing.php?type=leasing">Leasing</a></li>
                                        <li><a href="https://www.centralpark.in/crystaltown.php">Facility Management</a></li>
                                        <!--<li><a href="https://www.centralpark.in/pdf/CompiledSMCR_CPFV.pdf" target="_blank">Environmental Clearance</a></li>-->
                                    </ul>
                                </div>
                            </div>
                          <div class="footnavitem">
                                 <div class="footernavi">
                                    <strong>About Us</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/about-us.php">Who We Are</a></li>
                                       <li><a href="https://www.centralpark.in/about-us.php#vision">Vision</a></li>
                                        <li><a href="https://www.centralpark.in/about-us.php#awards">Awards</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/about-us.php#foundation">CSR</a></li>
                                       <li><a href="https://www.centralpark.in/blog/">Blogs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>NRI Corner</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/nri-corner.php">Why Central Park</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#whyindia">Why India</a></li>
                                       <li><a href="https://www.centralpark.in/nri-corner.php#faq">FAQ's</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Careers</strong>
                                    <ul>
                                       <li><a href="https://www.centralpark.in/careers.php">Join Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="footnavitem mr-lt30">
                                <div class="footernavi">
                                    <strong>Quick Links</strong>
                                    <ul>
                                                                               <li><a href="https://www.centralpark.in/refund-policy.php">Refund Policy</a></li>
                                       
                                       <li><a href="https://www.centralpark.in/privacy-policy.php">Privacy Policy</a></li>
                                                                              <li><a href="https://www.centralpark.in/terms-conditions.php">Terms & Conditions</a></li>
                                       
                                                                           </ul>
                                </div>
                            </div>
                            
<!--                          -->


                            
                            <!--<div class="footnavitem borderrightleft">-->
                            <!--    <div class="width90">-->
                            <!--        <div class="footernavi">-->
                            <!--            <strong style="line-height: 1.2;"> Download Our Newsletter</strong>-->
                            <!--            <p>To stay updated about the ongoing events in the Central Park community and unravel the best of your future, check out our newsletter, The Chronicle. </p>-->
                            <!--            <div class="infileds">-->
                                            
                            <!--                <form class="infileds" action="dataSubscribe.php" method="POST" id="subscribe_form">-->
                            <!--                <input type="text" class="form-email" placeholder="Enter Your Email" id="email_sub" name="email_sub" >-->
                            <!--                <input type="hidden" id="footerPage" value="subscribeForm">-->
                            <!--                <button class="btn btn_submit"  type="submit"><img src="https://www.centralpark.in/images/footer_icon.svg" width="40" height="8"  alt="footer icon"></button>-->
                            <!--                </form>-->
                            <!--            </div>                                      <p id="success2" style="color:green;font-size: 14px;"></p>  -->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
<div class="thereeranumber">
    <p><span>RERA NO.:</span>Mikasa Plot : RC/REP/HARERA/GGM/95 OF 2017/7(3)/32/2023/09, RC/REP/HARERA/GGM/395/127/2020/11, RC/REP/HARERA/GGM/562/294/2022/37 | Fleur Villas: RC/REP/HARERA/GGM/624/356/2022/99 | Aqua Front Towers & The Room: RC/REP/HARERA/GGM/150 OF 2017/7(3)/34/2023/11  | The Orchard: RC/REP/HARERA/GGM/672/404/2023/16 | Bignonia Tower: RC/REP/HARERA/GGM/826/558/2024/53 | Bellavista: RC/REP/HARERA/GGM/379/111/2019/73 | The Selene Tower: RC/REP/HARERA/GGM/964/696/2025/67 | <a href="https://haryanarera.gov.in/" target="_blank">Haryanarera.gov.in</a></p>
</div>
                    <div class="footermedia">
                        <div class="footnavgrid">
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong>Follow Us</strong>
                                    <ul>
                                        <li><a rel="nofollow" href="https://www.facebook.com/CentralParkIn/" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.instagram.com/centralparkin/"  target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                        <li><a rel="nofollow" href="https://www.youtube.com/channel/UCfAm2lsQoqJ5wt7Sssz6XwQ"  target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                        <!--<li><a rel="nofollow" href="https://twitter.com/CentralParkIn"  target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
                                        <li><a rel="nofollow" href="https://www.linkedin.com/company/central-park-in/"  target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp; ttt</strong>
                                </div>
                            </div>
                            <div class="footnavitem">
                                <div class="footernavi">
                                    <strong class="none">&nbsp;</strong>
                                    <p class="pd-lt40">&copy;Centralpark 2025. All Rights Reserved</p>
                                </div>
                            </div>
                            <input type="hidden" id="is_home" name="is_home" value="https://www.centralpark.in/">
                            <input type="hidden" id="c_page" name="c_page" value="central-park-the-room.php">
                        </div>
                    </div>
                </div>
            </div>
        </footer>

<!--
        <div class="copyrights">
            <div class="text-center">
                <span><a href="https://cogculture.agency" target="_blank"> <img src="https://www.centralpark.in/images/cclogo.svg" width="22" height="16" alt="cogdigital"></a></span>
            </div>
        </div>
-->
            
        <div id="modal-container-location">
          <div class="modal-background">
            <div class="modal bg-white cnt-modal"  id="ConnectusOpen">
                <a href="javascript:void(0)" class="closebutton" ><img src="https://www.centralpark.in/images/icon-close.svg" width="17" height="17" alt="Central Park Icon Close"></a>
                
                <div class="width90" >
                <iframe src=""  id="Connectus"  style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
          </div>
          </div>
          
        
    </div>
    
    <input type="hidden" value="central-park-the-room.php" id="is_home">
    
       
    <script src="https://www.centralpark.in/js/jquery.min.js"></script>    
    <script src="https://www.centralpark.in/js/wow.min.js"></script>
    <script src="https://www.centralpark.in/js/slick.js"></script>
    <script src="https://www.centralpark.in/js/eocjs-newsticker.js"></script>
    
    <script src="https://www.centralpark.in/js/gsap.js" defer ></script>
    <script src="https://www.centralpark.in/js/ScrollTrigger.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollMagic.js" defer></script>
    <script src="https://www.centralpark.in/js/animation.gsap.js" defer></script>
    <script src="https://www.centralpark.in/js/ScrollToPlugin.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@17.6.1/dist/lazyload.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/additional-methods.js"></script>
    <!--<script src='https://unpkg.com/axios/dist/axios.min.js'></script>-->
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.0.0-alpha.1/axios.min.js"></script>-->
    <script src="https://www.centralpark.in/js/validation.js"></script>
    <script src="https://www.centralpark.in/js/custom.js"></script>
  
    <script>
        $(document).ready(function(){
            $("#slidetext").eocjsNewsticker({
                speed: 20,
                timeout: 1,
                divider: '',
                type: 'static'
            });
            
            // $.ajax({
            // 		url:"https://www.centralpark.in/aqi.php",
            // 		method:"GET",
            // 		success:function(response){
            // 		    var res = jQuery.parseJSON(response)
            //                  $('#resort_aqi').html(res.aqi_1)
            //                  $('#sohna_road_aqi').html(res.aqi_2)
            // 		}
            // });

        });
        
        // (function test() {

        //     axios({
        //       "async": true,
        //       "crossDomain": true,
        //       "url": "https://production.oizom.com/v1/data/cur",
        //       "method": "GET",
        //       "headers": {
        //         "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwNzAsIm9yZ0lkIjoiQ1AyMDE5MDUwMSIsInVzZXJFbWFpbCI6ImNwMjAxOTA1MDFAb2l6b20uY29tIiwiaWF0IjoxNjU2NjY4OTY3LCJleHAiOjE2ODgyMDQ5NjcsImlzcyI6IkNWSm9HdUgwZWhRRzViZEhyMzg3Y0tPZ1Nra3BOcGRsIn0.8xkfajwKv7_-M1AvNi6sK9MDXn4jSngjPt0ahjGjDIM",
        //         "cache-control": "no-cache",
        //         "postman-token": "30042871-ce0e-2dd5-dcd8-5635ec6ec140"
        //       }
        //     }).then(function(response) {
        //                     $('#resort_aqi').html(response.data[0].aqi)
        //                     $('#sohna_road_aqi').html(response.data[1].aqi)
        //                 })

        // })();
    
    </script>   
   <script>
  gtag('event', 'conversion', {'send_to': 'AW-16495080556/Dv0oCKTs3aIZEOzou7k9'});
</script>

<script>
  window.addEventListener('load', function() {
    if(window.location.pathname==("/") && window.document.referrer.includes("thanks.php")){
      gtag('event', 'conversion', {'send_to': 'AW-16495080556/7JrQCKHs3aIZEOzou7k9'});
    }
  });
</script>

<script>
  (function(){
    document.addEventListener('click', function(e){
      if(e.target.closest('a[href^="tel:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/IHfTCKfs3aIZEOzou7k9'});
      }
      if(e.target.closest('a[href^="mailto:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/yPy_CKrs3aIZEOzou7k9'});
      }
    });
  })();
</script>
   
   <script>
    function loadMap(v){
      if(v=="1")
        var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3506.9840833843336!2d77.10016661436981!3d28.48002598247817!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf47ab06242fb836a!2sGLOBAL%20BUSINESS%20PARK!5e0!3m2!1sen!2sin!4v1622103095919!5m2!1sen!2sin";
          
      if(v=="2")
        //   var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3508.830867361511!2d77.03224111507788!3d28.424359882500486!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbd478862f690aeca!2sCentral+Park+The+Resort!5e0!3m2!1sen!2sin!4v1530170396691";
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2481.144333967807!2d77.03577665122448!3d28.423240585612685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1878dee37f57%3A0xa9ecdd7d72782cf6!2sCentral%20Park%C2%AE!5e0!3m2!1sen!2sin!4v1649670949376!5m2!1sen!2sin";
            
            
            if(v=="3")
    
            var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
            
              
      if(v=="5")
           var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
      
       if(v=="6")
           var loc ="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3511.281450826602!2d77.06318704995007!3d28.350339303463272!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d233202703f8f%3A0x6069d5f67eb02f07!2sThe%20Room!5e0!3m2!1sen!2sin!4v1626854192717!5m2!1sen!2sin";
           
        if(v=="4")
          var loc = "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14035.267568735091!2d77.0347599!3d28.4247815!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x57c9a489284d2d27!2sBella%20Vista!5e0!3m2!1sen!2sin!4v1646810366352!5m2!1sen!2sin";
      
      document.getElementById("Connectus").setAttribute('src', loc);
      $('.wellnes-open').css("transform", "translate(0px, 0%)")  
      }
      function closeBtn(a){
         $('#ConnectusOpen').css("transform", "translate(0px, 100%)")
         document.getElementById("Connectus").setAttribute('src','');
      }
      
</script>
 <script>
//     $(".thebuttonnsd button").click(function () {
//     $(".cookiesaccept").css("display", "none");
// });
// </script>
 <script>
// // Function to set a cookie with a 1-day expiration
// function setCookie(name, value, days) {
//     var date = new Date();
//     date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
//     var expires = "expires=" + date.toUTCString();
//     document.cookie = name + "=" + value + ";" + expires + ";path=/";
// }

// // Add event listener to button
// document.getElementById('setCookieBtn').addEventListener('click', function() {
//     setCookie('myCookie', 'cookieValue', 1); // Set cookie for 1 day
//     alert('Cookie set for 1 day!');
// });
// </script>

<script>
    // Function to set a cookie with a specified expiration in days
    function setCookie(name, value, days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000)); // Days to milliseconds
        var expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    // Function to get a specific cookie by name
    function getCookie(name) {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.indexOf(name + "=") == 0) {
                return cookie.substring(name.length + 1);
            }
        }
        return "";
    }

    // Function to hide the cookie notice
    function hideCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'none';
    }

    // Function to show the cookie notice
    function showCookieNotice() {
        document.getElementById('cookieNotice').style.display = 'block';
    }

    // Add event listener for 'Accept All' button
    document.getElementById('setCookieBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'true', 1); // Set cookie for 1 day
        hideCookieNotice(); // Hide cookie notice after acceptance
    });

    // Add event listener for 'Reject All' button (optional behavior)
    document.getElementById('rejectCookiesBtn').addEventListener('click', function() {
        setCookie('acceptedCookies', 'false', 1); // Set rejection cookie
        hideCookieNotice(); // Hide cookie notice after rejection
    });

    // Function to check if the cookie is already set
    function checkCookie() {
        var acceptedCookies = getCookie('acceptedCookies');
        if (acceptedCookies === 'true') {
            hideCookieNotice(); // If cookies were accepted, hide the notice
        } else {
            showCookieNotice(); // If no cookie or rejected, show the notice
        }
    }

    // Run the checkCookie function on page load
    window.onload = checkCookie;
    </script>
     <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script>
    var swiper = new Swiper(".mySwipertest", {
      slidesPerView: 3,
      spaceBetween: 30,
    //   loop:true,
      autoplay: {
        delay: 50500,
        disableOnInteraction: false,
      },
        breakpoints: {
              320: {
          slidesPerView: 1,
          spaceBetween: 20,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 40,
        },
        1024: {
          slidesPerView: 3,
          spaceBetween: 50,
        },
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });
  </script>
</body>
</html><!--<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.0/TweenMax.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.2/ScrollMagic.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.2/plugins/animation.gsap.js"></script>-->
<!--<script>
let scroll_tl = gsap.timeline({
        scrollTrigger: {
            trigger: '.factsContainer',
            start: "top center",
            // pin: true,
            scrub: true,
            end: "+=300",
            // markers: true,
        }
    }),
        facts = [...document.querySelectorAll('.anemities-box')]
    scroll_tl.to('.factsContainer h2', {
        scale: 1.5,
        duration: 1,
        ease: "slow"
    })
    scroll_tl.to(facts, {
        xPercent: -50 * (facts.length - 1),
        scrollTrigger: {
            trigger: ".factsContainer_sm",
            start: "center center",
            pin: true,
            // horizontal: true,
            // pinSpacing:false,
            // markers: true,
            scrub: 1,
            //snap: 1 / (facts.length - 1),
            // base vertical scrolling on how wide the container is so it feels more natural.
            // end: () => `+=${smallFactsContainer.offsetWidth}`
            end: () => `+=4320`
        }
    });
</script>-->
<script>
    function loadViewMap(v){
    if(v=="3"){
        //var loc = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3513.477415285826!2d77.06610441507476!3d28.283858682556613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb12ed47e47baed2!2sCentral+Park+Flower+Valley!5e0!3m2!1sen!2sin!4v1524634877889";
        var loc = "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d112239.35285316235!2d76.9706725!3d28.4650945!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d18759215f28d%3A0xe730e0f21b47341c!2sThe%20Room%2C%20Central%20Park%20II%2C%20Sector%2048%2C%20Gurgaon%2C%20Haryana%2C%20India%2C%20CENTRAL%20PARK%20IN%2C%20Central%20Park%20II%20Rd%2C%20Central%20Park%20II%2C%20Sector%2048%2C%20Gurugram%2C%20Haryana%20122004!5e0!3m2!1sen!2sin!4v1695886929450!5m2!1sen!2sin";
        document.getElementById("Connectus").setAttribute('src', loc);
          $('.wellnes-open').css("transform", "translate(0px, 0%)")    
      }
}
function closeBtn(a){
     $('#ConnectusOpen').css("transform", "translate(0px, 100%)")
     document.getElementById("Connectus").setAttribute('src','');
      
  }
</script>