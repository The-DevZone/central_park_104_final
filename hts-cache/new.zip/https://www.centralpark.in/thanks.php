<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="theme-color" content="#ffffff" />
        <title>Central Park Home</title>
        <link rel="shortcut icon" type="images/png" href="images/favi.png" />

        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" href="css/animate.css" />
        <style>
            * {
                margin: 0;
                padding: 0;
                -webkit-box-sizing: border-box;
                        box-sizing: border-box;
            }
            body,
            html {
                width: 100%;
                height: 100%;
            }
            .thanks-container {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                /*align-items: center;*/
                height: 100%;
                background-color: #f9f9f9;
                background: url("images/thank.jpg") no-repeat;
                background-size: cover !important;
            }
            .thanks-inner {
                padding: 27px 4px;
                /* background: #ffffff26; */
                font-size: 24px;
                line-height: 36px;
                color: #000;
                text-align: left;
                margin: 0;
                background: #fff;
                /*width: 500px;*/
                padding: 90px 60px;
            }

            .thanks-container .width90 {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-align: center;
                    -ms-flex-align: center;
                        align-items: center;
            }
            .thanks-inner p {
                /* font-family: 'Freight'; */
                font-size: 20px;
                line-height: 1.4;
                margin-bottom: 7px;
                opacity: 0.6;
                color: #000;
                /* font-weight: 600; */
            }
            
            .btn:hover{
                    color: #3e3e3e;
            }
            .btn.btn_submit {
    padding: 0;
    margin-top: 15px;
}

            .thanks-inner .mb-5 {
                line-height: 0.8 !important;
                margin-bottom: 20px !important;
                color: #000;
                line-height: 1.2;
                opacity: 1;
                width: 100%;
                font-family: "Freight";
                font-weight: normal;
                font-size: 56px;
                color: #3e3e3e;
            }

            @media (max-width: 767px) {
                .thanks-container .width90 {
        align-items: flex-end;
        margin-bottom: 50px;
    }
                .thanks-inner .mb-5 {
                    font-size: 40px;
                    line-height: 1.1;
                    opacity: 1;
                }
                .thanks-inner p {
                    font-size: 16px;
                }
                .thanks-container {
    background: url(images/thank.jpg) no-repeat right;
    background-position-x: 80%;
}
            }

            @media (max-width: 480px) {
                .thanks-inner {
                    padding: 40px;
                }
            }
        </style>
        
        <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16495080556"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-16495080556');
</script>
    </head>

    <body>
        <!-- Event snippet for Website Traffic views conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-16495080556/Dv0oCKTs3aIZEOzou7k9'});
</script>
        <div class="thanks-container">
            <div class="width90">
                <div class="thanks-inner">
                                        <p class="mb-5 wow animate__animated animate__fadeInUp"> Thanks for<br /> contacting us. </p>
                    <p class="wow animate__animated animate__fadeInUp">We shall revert to your enquiry shortly.</p>
                      <a class="btn btn_submit" href="https://www.centralpark.in/" style="border-bottom: solid 1px #000;border-radius: 0;  display: inline-block;   width: 33%;" >
                        Back to Home
                    </a>
                                        
                    
                    
                    
                     
                </div>
            </div>
        </div>
    </body>
    
    <script>
  window.addEventListener('load', function() {
    if(window.location.pathname==("/") && window.document.referrer.includes("thanks.php")){
      gtag('event', 'conversion', {'send_to': 'AW-16495080556/7JrQCKHs3aIZEOzou7k9'});
    }
  });
</script>

<script>
  (function(){
    document.addEventListener('click', function(e){
      if(e.target.closest('a[href^="tel:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/IHfTCKfs3aIZEOzou7k9'});
      }
      if(e.target.closest('a[href^="mailto:"]')){
        gtag('event', 'conversion', {'send_to': 'AW-16495080556/yPy_CKrs3aIZEOzou7k9'});
      }
    });
  })();
</script>
</html>

<script type="text/javascript">
setTimeout(function(){
window.location.href="https://www.centralpark.in/";
},5000);
</script>
